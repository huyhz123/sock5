# GSM Ultimate v3.0 - WordPress Theme

**Professional GSM Services Theme with Multi-language, Multi-currency & API Integration**

## 📋 Features

### ✨ Core Features
- ✅ **Multi-language Support** (EN, VI, ZH) - WordPress i18n compatible
- ✅ **Multi-currency System** (USD, VND, CNY) - Automatic conversion
- ✅ **4 Product Types** - Services, Accounts, Phones, Parts
- ✅ **IMEI API Integration** - GSMTOOL & DHRU Fusion ready
- ✅ **2025 Modern UI/UX** - Glassmorphism, Neumorphism, Particles.js
- ✅ **Fully Responsive** - Mobile-first design
- ✅ **SEO Optimized** - Clean semantic HTML
- ✅ **Contact Form** - Built-in with email notifications
- ✅ **Professional Comments** - Modern card-based design
- ✅ **Floating Contact Buttons** - WhatsApp, Zalo, Telegram, Phone

### 🎨 Design
- Modern flat design with glassmorphism effects
- Black-gray-light color scheme
- Smooth animations and transitions
- Particles.js hero banner
- Card-based layouts
- Responsive grid system

### 🛠 Technical
- WordPress 5.0+ compatible
- PHP 7.4+ required
- jQuery included
- No external dependencies
- Clean, validated code
- Security best practices

## 📦 Installation

### Method 1: WordPress Admin
1. Download the theme folder
2. Compress `gsm-ultimate-v3` folder as ZIP
3. Go to **WordPress Admin → Appearance → Themes**
4. Click **Add New → Upload Theme**
5. Select the ZIP file
6. Click **Install Now**
7. Click **Activate**

### Method 2: FTP Upload
1. Extract the theme folder
2. Upload `gsm-ultimate-v3` folder to `/wp-content/themes/`
3. Go to **WordPress Admin → Appearance → Themes**
4. Find "GSM Ultimate v3.0" and click **Activate**

## ⚙️ Configuration

### 1. Site Identity
Go to **Customizer → Site Identity**:
- Logo Text: Hz (or your text)

### 2. Contact Information
Go to **Customizer → Contact Information**:
- Hotline: +84386355255
- WhatsApp: +84386355255
- Zalo: +84386355255
- Telegram: @hzgsm
- Email: contact@hzgsm.com

### 3. Hero Banner
Go to **Customizer → Hero Banner**:
- Hero Title
- Hero Subtitle
- Background Video URL (optional)

### 4. API Settings
Go to **Customizer → API Settings**:
- GSMTOOL API Key
- DHRU Username
- DHRU API Key

### 5. Navigation Menu
1. Go to **Appearance → Menus**
2. Create a new menu
3. Add pages/links
4. Assign to "Primary Menu" location

## 📄 Creating Content

### Products (Services, Accounts, Phones, Parts)
1. Go to **Services** (or Accounts/Phones/Parts)
2. Click **Add New**
3. Enter title and description
4. Add featured image
5. Fill in Product Details:
   - Price (USD)
   - Old Price (optional)
   - Stock Status
   - SKU
   - Warranty
6. Select category
7. Click **Publish**

### Blog Posts
1. Go to **Posts → Add New**
2. Enter title and content
3. Add featured image
4. Select category and tags
5. Click **Publish**

### Pages
1. Go to **Pages → Add New**
2. Enter title and content
3. For contact page, select template: **Contact Page**
4. Click **Publish**

## 🌐 Multi-language Setup

### Using .po/.mo Files (Recommended)
1. Go to `/wp-content/themes/gsm-ultimate-v3/languages/`
2. Create translation files:
   - `gsm-ultimate-en_US.po`
   - `gsm-ultimate-vi.po`
   - `gsm-ultimate-zh_CN.po`
3. Use Poedit to translate strings
4. Upload .po and .mo files

### Using WPML/Polylang (Alternative)
1. Install WPML or Polylang plugin
2. Create translations for pages/posts
3. Theme will work seamlessly

## 💰 Currency Configuration

The theme comes with 3 currencies pre-configured:
- **USD** ($) - Base currency, rate: 1
- **VND** (₫) - Rate: 24000
- **CNY** (¥) - Rate: 7.2

To change rates, edit `/functions.php` line 143:
```php
private static $currencies = array(
    'USD' => array('symbol' => '$', 'rate' => 1, 'decimals' => 2),
    'VND' => array('symbol' => '₫', 'rate' => 24000, 'decimals' => 0),
    'CNY' => array('symbol' => '¥', 'rate' => 7.2, 'decimals' => 2),
);
```

## 🔌 IMEI API Integration

### GSMTOOL API
1. Get API key from https://gsmtool.com
2. Add to **Customizer → API Settings → GSMTOOL API Key**
3. Use in code:
```php
$api = new GSM_GSMTOOL_API();
$result = $api->check_imei('123456789012345');
```

### DHRU Fusion API
1. Get credentials from https://www.dhru.com
2. Add to **Customizer → API Settings**
3. Use in code:
```php
$api = new GSM_DHRU_API();
$result = $api->check_imei('123456789012345', 'service_id');
```

## 📱 Contact Methods

Floating contact buttons appear on all pages:
- Phone (calls hotline)
- WhatsApp (opens chat)
- Zalo (opens chat)
- Telegram (opens chat)

Configure numbers in **Customizer → Contact Information**.

## 🎯 Buy Button

Currently, buy buttons link to phone call (tel: link).

To add shopping cart:
1. Install WooCommerce plugin, OR
2. Create custom cart system using hooks

## 🎨 Customization

### Colors
Edit `/style.css` CSS variables (line 35):
```css
:root {
    --color-primary: #ff9800;
    --color-black: #0a0a0a;
    /* ... more colors */
}
```

### Typography
Edit `/style.css` typography variables (line 60):
```css
:root {
    --font-primary: -apple-system, ...;
    --font-size-base: 16px;
}
```

### Logo
Replace `/assets/images/logo-hz.svg` with your logo.

## 📊 Sample Content

Theme auto-creates sample content on activation:
- 3 Services
- 2 Accounts
- 2 Phones
- 2 Parts
- 3 Blog posts

Delete or edit as needed.

## 🔒 Security Features

- CSRF protection (nonces)
- Input sanitization
- SQL injection prevention
- XSS prevention
- Secure AJAX calls

## 🐛 Troubleshooting

### Language not changing
1. Clear browser cookies
2. Check `/languages/` folder exists
3. Ensure `load_theme_textdomain()` is called

### Currency not displaying
1. Check cookie `gsm_currency` is set
2. Clear browser cache
3. Check JavaScript console for errors

### Products not showing
1. Go to **Settings → Permalinks**
2. Click **Save Changes** (flush rewrite rules)

### Contact form not working
1. Check WordPress email settings
2. Install SMTP plugin (WP Mail SMTP)
3. Check spam folder

## 📝 File Structure

```
gsm-ultimate-v3/
├── style.css              # Main stylesheet (1500+ lines)
├── functions.php          # Theme functions (850+ lines)
├── header.php             # Header template
├── footer.php             # Footer template
├── front-page.php         # Homepage template
├── index.php              # Blog listing
├── single.php             # Single blog post
├── single-product.php     # Single product (all types)
├── archive.php            # Product archives
├── page.php               # General pages
├── page-contact.php       # Contact page template
├── comments.php           # Modern comments
├── assets/
│   ├── js/
│   │   └── main.js        # Main JavaScript
│   └── images/
│       └── logo-hz.svg    # Hz logo
├── languages/             # Translation files (.po/.mo)
└── README.md              # This file
```

## 🆘 Support

**Contact Information:**
- Phone/WhatsApp/Zalo: +84386355255
- Telegram: @hzgsm
- Email: contact@hzgsm.com

## 📜 License

GNU General Public License v2 or later
http://www.gnu.org/licenses/gpl-2.0.html

## 🎉 Credits

**Theme by:** HzGSM
**Version:** 3.0.0
**Release Date:** 2025

### Libraries Used:
- jQuery (WordPress core)
- Font Awesome 6.4.0
- Particles.js 2.0.0
- Google Fonts (Inter)

## 🔄 Changelog

### Version 3.1.0 (2025) - BRIGHT EDITION
- ✅ **NEW:** Bright modern UI theme (no more dark!)
- ✅ **NEW:** Auto cache clear system (supports all major plugins)
- ✅ **NEW:** Optimized language system with caching
- ✅ **NEW:** Clear Cache button in admin bar
- ✅ **NEW:** Daily auto cache clear scheduled
- ✅ Updated color scheme to bright/light theme
- ✅ Improved glassmorphism with lighter tones
- ✅ Enhanced performance with translation caching
- ✅ Better language cookie handling

### Version 3.0.0 (2025)
- ✅ Fixed multi-language switching (WordPress i18n)
- ✅ Redesigned product information page (modern cards)
- ✅ Redesigned comment system (card-based)
- ✅ Added working buy button (tel: link)
- ✅ Created missing service pages
- ✅ Integrated IMEI APIs (GSMTOOL & DHRU)
- ✅ Created professional Hz logo
- ✅ Added 2025 style banner with particles.js
- ✅ Full optimization (images, CSS, performance)
- ✅ Added advanced settings in Customizer
- ✅ Complete testing and validation

### Previous Versions
- v2.0 - Multi-language attempt (cookie-based - not working)
- v1.0 - Initial release

---

**Made with ❤️ by HzGSM**
**Contact: +84386355255 | @hzgsm**
