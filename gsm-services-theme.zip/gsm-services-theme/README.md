# GSM Services Pro - WordPress Theme

**Enterprise-Grade WordPress Theme for GSM Services Platform**

A professional, security-hardened WordPress theme designed for GSM service providers, featuring 2FA authentication, role-based access control, payment gateway integration, and comprehensive service management.

---

## 🌟 Features

### 🔒 Security Features
- ✅ **Two-Factor Authentication (2FA/TOTP)** - RFC 6238 compliant
- ✅ **Role-Based Access Control (RBAC)** - Custom roles and capabilities
- ✅ **CSRF Protection** - All forms protected with nonces
- ✅ **XSS Protection** - All outputs properly escaped
- ✅ **SQL Injection Prevention** - WordPress prepared statements
- ✅ **Security Headers** - CSP, HSTS, X-Frame-Options, etc.
- ✅ **Login Rate Limiting** - Prevent brute-force attacks
- ✅ **Audit Logging** - Track all admin actions
- ✅ **Session Security** - Secure cookies, timeout controls
- ✅ **Password Policy** - Strong password enforcement

### 💼 Business Features
- ✅ **Custom Post Types** - Services, Orders, Tickets
- ✅ **Wallet System** - User balance management
- ✅ **Commission Tracking** - Partner/dealer commissions
- ✅ **Payment Gateways** - Stripe, PayPal integration
- ✅ **Notification System** - Telegram, WhatsApp alerts
- ✅ **Ticket System** - Customer support ticketing
- ✅ **Service Catalog** - IMEI services, unlocking, FRP removal
- ✅ **Order Management** - Complete order workflow
- ✅ **Multi-Role Support** - Admin, Manager, Staff, Partner, Dealer, Customer

### 🎨 Frontend Features
- ✅ Responsive design
- ✅ Clean, modern UI
- ✅ User account dashboard
- ✅ Service browsing and ordering
- ✅ Order history and tracking
- ✅ Ticket creation and management
- ✅ Wallet top-up interface
- ✅ Multi-language ready

---

## 📋 Requirements

### Minimum Requirements
- **WordPress**: 6.0 or higher
- **PHP**: 7.4 or higher (8.0+ recommended)
- **MySQL**: 5.7 or higher (MariaDB 10.3+)
- **HTTPS**: SSL certificate (required for production)

### Recommended Server
- **PHP**: 8.1 or higher
- **Memory**: 256MB minimum, 512MB recommended
- **PHP Extensions**: `openssl`, `gd`, `mbstring`, `curl`, `json`

---

## 🚀 Installation

### Step 1: Upload Theme

**Option A: Via WordPress Admin**
1. Go to `Appearance > Themes > Add New`
2. Click `Upload Theme`
3. Choose `gsm-services-theme.zip`
4. Click `Install Now`
5. Click `Activate`

**Option B: Via FTP**
1. Extract `gsm-services-theme.zip`
2. Upload `gsm-services-theme` folder to `/wp-content/themes/`
3. Go to `Appearance > Themes`
4. Activate "GSM Services Pro"

### Step 2: Install Required Plugins

The theme works standalone but recommends these plugins:
- **Contact Form 7** - For additional forms
- **Yoast SEO** - For SEO optimization
- **WP Mail SMTP** - For email delivery

### Step 3: Configure Theme Settings

1. Go to `GSM Settings > General Settings`
2. Configure:
   - Site name and description
   - Currency settings
   - Timezone

3. Go to `GSM Settings > Payment Gateways`
4. Configure payment methods:
   - **Stripe**: Add API keys
   - **PayPal**: Add Client ID and Secret

5. Go to `GSM Settings > Notifications`
6. Configure:
   - **Telegram Bot**: Add bot token and chat ID
   - **WhatsApp**: Add API credentials

### Step 4: Set Up Menus

1. Go to `Appearance > Menus`
2. Create menus for:
   - Primary Navigation
   - Footer Navigation
   - Account Navigation

### Step 5: Configure Permalinks

1. Go to `Settings > Permalinks`
2. Choose "Post name" structure
3. Save changes

---

## 🔐 Security Setup

### Enable 2FA for Admin

**CRITICAL: Enable 2FA immediately after installation**

1. Login as administrator
2. Go to `Users > Your Profile`
3. Scroll to "Two-Factor Authentication"
4. Click "Enable 2FA"
5. Scan QR code with Google Authenticator or Authy
6. **Save backup codes** in a secure location
7. Enter verification code to confirm

### Configure Security Settings

1. Go to `GSM Settings > Security`
2. Configure:
   - **Force 2FA for Admins**: Enable (recommended)
   - **Login Attempts**: 5 attempts / 15 minutes (default)
   - **Session Timeout**: 30 minutes (adjustable)
   - **Audit Log Retention**: 90 days

### SSL/HTTPS Setup

**Required for production:**

```bash
# Install Let's Encrypt certificate
sudo certbot --apache -d yourdomain.com

# Or for Nginx
sudo certbot --nginx -d yourdomain.com
```

Then in WordPress:
1. Go to `Settings > General`
2. Update both URLs to use `https://`
3. Save changes

---

## 👥 User Roles

The theme adds custom roles:

| Role | Capabilities |
|------|-------------|
| **Administrator** | Full access, manage everything |
| **Manager** | Manage services, orders, tickets |
| **Staff** | Process orders, respond to tickets |
| **Partner** | View services, create orders, earn commissions |
| **Dealer** | View services, create orders at dealer pricing |
| **Customer** | Browse services, place orders, create tickets |

---

## 💳 Payment Gateway Setup

### Stripe Configuration

1. Create Stripe account at https://stripe.com
2. Go to Dashboard > Developers > API keys
3. Copy **Publishable key** and **Secret key**
4. In WordPress: `GSM Settings > Payment Gateways > Stripe`
5. Paste keys and enable

**Test Mode:**
- Use test keys for development
- Test card: `4242 4242 4242 4242`

### PayPal Configuration

1. Create PayPal business account
2. Go to https://developer.paypal.com
3. Create REST API app
4. Copy **Client ID** and **Secret**
5. In WordPress: `GSM Settings > Payment Gateways > PayPal`
6. Paste credentials
7. Choose mode: Sandbox (test) or Live

---

## 📲 Notification Setup

### Telegram Bot

1. **Create Bot:**
   - Open Telegram, message @BotFather
   - Send `/newbot`
   - Follow instructions
   - Copy **bot token**

2. **Get Chat ID:**
   ```bash
   # Send message to your bot, then:
   curl https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates
   # Find "chat":{"id":123456789}
   ```

3. **Configure in WordPress:**
   - Go to `GSM Settings > Notifications > Telegram`
   - Paste bot token and chat ID
   - Test connection

### WhatsApp Business API

1. Set up at https://developers.facebook.com/
2. Create Business App
3. Add WhatsApp product
4. Get **Phone Number ID** and **Access Token**
5. Configure in `GSM Settings > Notifications > WhatsApp`

---

## 🛠️ Custom Post Types

### Services (gsm_service)

**Create a service:**
1. Go to `GSM Services > Add New`
2. Enter service details:
   - Title (e.g., "iPhone IMEI Check")
   - Description
   - Price (regular, dealer, partner)
   - Delivery time
   - Requirements (IMEI, model, etc.)
3. Assign to category
4. Set featured image
5. Publish

### Orders (gsm_order)

Orders are created automatically when customers place orders.

**Manage orders:**
1. Go to `GSM Orders`
2. View pending orders
3. Process manually or via API
4. Update status (pending → processing → completed)
5. Add admin notes

### Tickets (gsm_ticket)

**View tickets:**
1. Go to `GSM Tickets`
2. Assign to staff
3. Respond to customer inquiries
4. Close when resolved

---

## 🎨 Customization

### Theme Options

Go to `Appearance > Customize`:
- **Site Identity**: Logo, site icon
- **Colors**: Primary, secondary colors
- **Typography**: Font families
- **Layout**: Sidebar position
- **Footer**: Copyright text

### Custom CSS

Add custom styles:
1. `Appearance > Customize > Additional CSS`
2. Or edit `/assets/css/custom.css`

### Template Overrides

Override templates by copying from theme to child theme:
```
gsm-services-theme/templates/services/single-service.php
→ gsm-services-child/templates/services/single-service.php
```

---

## 📊 Shortcodes

The theme provides useful shortcodes:

```php
// Display services
[gsm_services category="imei-check" limit="6"]

// User account dashboard
[gsm_account_dashboard]

// Order history
[gsm_orders]

// Ticket list
[gsm_tickets]

// Wallet balance
[gsm_wallet_balance]

// Service search
[gsm_service_search]
```

---

## 🔧 Cron Jobs

The theme uses WordPress cron for background tasks:

**Notification Queue:**
- Runs: Every minute
- Processes pending Telegram/WhatsApp notifications

**Audit Log Cleanup:**
- Runs: Daily
- Removes logs older than retention period

**To use server cron (recommended for production):**

1. Disable WP-Cron in `wp-config.php`:
   ```php
   define('DISABLE_WP_CRON', true);
   ```

2. Add to server cron:
   ```cron
   */1 * * * * wget -q -O - https://yourdomain.com/wp-cron.php?doing_wp_cron
   ```

---

## 🐛 Troubleshooting

### Issue: Can't login / "Too many attempts"

**Solution:**
```php
// Clear rate limit transients
delete_transient('gsm_login_attempts_*');

// Or wait 15 minutes
```

### Issue: 2FA not working

**Solution:**
1. Check server time is accurate (TOTP requires sync)
2. Verify QR code scanned correctly
3. Use backup code to access account
4. Disable 2FA via database if locked out:
   ```sql
   UPDATE wp_gsm_2fa_secrets SET enabled = 0 WHERE user_id = 1;
   ```

### Issue: Payments not processing

**Solution:**
1. Check API credentials are correct
2. Verify SSL certificate is valid
3. Check error logs: `wp-content/debug.log`
4. Test in sandbox/test mode first

### Issue: Notifications not sending

**Solution:**
1. Check cron is running: `Tools > Site Health > Scheduled Events`
2. Verify API credentials
3. Check notification queue table
4. Test connection in settings page

---

## 📁 File Structure

```
gsm-services-theme/
├── style.css                    # Theme stylesheet with metadata
├── functions.php                # Main theme functions
├── index.php                    # Main template
├── header.php                   # Header template
├── footer.php                   # Footer template
├── single.php                   # Single post template
├── page.php                     # Page template
├── assets/
│   ├── css/                     # Stylesheets
│   ├── js/                      # JavaScript files
│   └── images/                  # Theme images
├── includes/
│   ├── security/                # Security classes
│   │   ├── class-gsm-security.php
│   │   ├── class-gsm-2fa.php
│   │   ├── class-gsm-totp.php
│   │   └── class-gsm-csrf.php
│   ├── custom-post-types/       # CPT definitions
│   ├── admin/                   # Admin functionality
│   ├── payments/                # Payment gateways
│   ├── notifications/           # Notification system
│   ├── class-gsm-user-account.php
│   ├── class-gsm-order-manager.php
│   ├── ajax-handlers.php
│   └── template-functions.php
├── templates/
│   ├── services/                # Service templates
│   ├── orders/                  # Order templates
│   ├── tickets/                 # Ticket templates
│   └── account/                 # Account templates
├── languages/                   # Translation files
└── README.md                    # This file
```

---

## 🔄 Updates

### Theme Updates

**Manual update:**
1. Backup current theme
2. Download new version
3. Upload and overwrite
4. Clear cache

**Automatic updates** (future):
- Will be available via WordPress.org

---

## 🆘 Support & Documentation

### Getting Help

1. **Documentation**: Read this README thoroughly
2. **WordPress Codex**: https://codex.wordpress.org
3. **Support Forum**: Submit issue on GitHub
4. **Email Support**: support@gsmservices.pro

### Useful Resources

- **WordPress Functions**: https://developer.wordpress.org/reference/
- **Security Best Practices**: https://wordpress.org/support/article/hardening-wordpress/
- **Stripe Documentation**: https://stripe.com/docs
- **PayPal API**: https://developer.paypal.com

---

## 📜 License

This theme is licensed under the GPL v2 or later.

```
Copyright (C) 2024 GSM Services Team

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
```

---

## 🎯 Changelog

### Version 1.0.0 (2024)
- Initial release
- Two-Factor Authentication (2FA)
- Role-Based Access Control (RBAC)
- Payment gateway integration (Stripe, PayPal)
- Notification system (Telegram, WhatsApp)
- Wallet and commission system
- Ticket support system
- Security hardening features
- Audit logging
- Custom post types (Services, Orders, Tickets)
- Responsive design

---

## ✅ Post-Installation Checklist

After installing the theme:

- [ ] Activate theme
- [ ] Configure permalink structure
- [ ] Set up menus
- [ ] Install SSL certificate
- [ ] Update WordPress URLs to HTTPS
- [ ] Enable 2FA for admin account
- [ ] Configure payment gateways
- [ ] Set up notification system
- [ ] Create service categories
- [ ] Add initial services
- [ ] Test order workflow
- [ ] Test payment processing
- [ ] Test notifications
- [ ] Configure security settings
- [ ] Set up cron jobs
- [ ] Create user roles
- [ ] Test ticket system
- [ ] Add legal pages (Terms, Privacy)
- [ ] Configure tax settings (if needed)
- [ ] Set up backup system
- [ ] Test on mobile devices
- [ ] Train staff on system usage

---

**🎉 Thank you for choosing GSM Services Pro!**

For the best experience, ensure all security features are properly configured and tested before going live.

**🔒 Security First. Always.**
