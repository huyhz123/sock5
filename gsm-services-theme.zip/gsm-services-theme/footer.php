<?php
/**
 * The footer template
 *
 * @package GSM_Services_Pro
 */
?>

<footer class="site-footer">
    <div class="container">
        <?php if (is_active_sidebar('footer-1')) : ?>
            <div class="footer-widgets">
                <?php dynamic_sidebar('footer-1'); ?>
            </div>
        <?php endif; ?>

        <div class="footer-info">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('All rights reserved.', 'gsm-services'); ?></p>
            <p class="security-info">
                <span class="security-badge">
                    <?php _e('Secured with 2FA & Enterprise Security', 'gsm-services'); ?>
                </span>
            </p>
        </div>

        <?php
        wp_nav_menu(array(
            'theme_location' => 'footer',
            'menu_class' => 'footer-menu',
            'container' => 'nav',
            'container_class' => 'footer-navigation',
            'fallback_cb' => false,
        ));
        ?>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
