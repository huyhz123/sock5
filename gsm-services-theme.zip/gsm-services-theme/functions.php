<?php
/**
 * GSM Services Pro - WordPress Theme
 *
 * Enterprise-grade theme with security hardening, 2FA, RBAC, and payment integration
 *
 * @package GSM_Services_Pro
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define theme constants
define('GSM_THEME_VERSION', '1.0.0');
define('GSM_THEME_PATH', get_template_directory());
define('GSM_THEME_URL', get_template_directory_uri());
define('GSM_INCLUDES_PATH', GSM_THEME_PATH . '/includes');

/**
 * Theme Setup
 */
function gsm_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('customize-selective-refresh-widgets');

    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'gsm-services'),
        'footer' => __('Footer Menu', 'gsm-services'),
        'account' => __('Account Menu', 'gsm-services'),
    ));

    // Add image sizes
    add_image_size('gsm-service-thumb', 400, 300, true);
    add_image_size('gsm-service-large', 800, 600, true);

    // Load text domain
    load_theme_textdomain('gsm-services', GSM_THEME_PATH . '/languages');
}
add_action('after_setup_theme', 'gsm_theme_setup');

/**
 * Enqueue Scripts and Styles
 */
function gsm_enqueue_scripts() {
    // Styles
    wp_enqueue_style('gsm-style', get_stylesheet_uri(), array(), GSM_THEME_VERSION);
    wp_enqueue_style('gsm-main', GSM_THEME_URL . '/assets/css/main.css', array(), GSM_THEME_VERSION);

    // Scripts
    wp_enqueue_script('gsm-main', GSM_THEME_URL . '/assets/js/main.js', array('jquery'), GSM_THEME_VERSION, true);

    // Localize script with AJAX URL and nonce for security
    wp_localize_script('gsm-main', 'gsmAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('gsm-ajax-nonce'),
        'siteUrl' => home_url('/'),
    ));

    // Conditional scripts
    if (is_singular('gsm_service')) {
        wp_enqueue_script('gsm-service-order', GSM_THEME_URL . '/assets/js/service-order.js', array('jquery'), GSM_THEME_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'gsm_enqueue_scripts');

/**
 * Register Widget Areas
 */
function gsm_widgets_init() {
    register_sidebar(array(
        'name' => __('Sidebar', 'gsm-services'),
        'id' => 'sidebar-1',
        'description' => __('Add widgets here.', 'gsm-services'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => __('Footer Area', 'gsm-services'),
        'id' => 'footer-1',
        'description' => __('Add footer widgets here.', 'gsm-services'),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="footer-widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'gsm_widgets_init');

/**
 * Security Hardening
 */
require_once GSM_INCLUDES_PATH . '/security/class-gsm-security.php';
require_once GSM_INCLUDES_PATH . '/security/class-gsm-2fa.php';
require_once GSM_INCLUDES_PATH . '/security/class-gsm-totp.php';
require_once GSM_INCLUDES_PATH . '/security/class-gsm-csrf.php';

/**
 * Custom Post Types
 */
require_once GSM_INCLUDES_PATH . '/custom-post-types/class-gsm-service-cpt.php';
require_once GSM_INCLUDES_PATH . '/custom-post-types/class-gsm-order-cpt.php';
require_once GSM_INCLUDES_PATH . '/custom-post-types/class-gsm-ticket-cpt.php';

/**
 * Admin Functionality
 */
if (is_admin()) {
    require_once GSM_INCLUDES_PATH . '/admin/class-gsm-admin.php';
    require_once GSM_INCLUDES_PATH . '/admin/class-gsm-settings.php';
    require_once GSM_INCLUDES_PATH . '/admin/class-gsm-roles.php';
}

/**
 * Payment Gateways
 */
require_once GSM_INCLUDES_PATH . '/payments/class-gsm-payment-gateway.php';
require_once GSM_INCLUDES_PATH . '/payments/class-gsm-stripe.php';
require_once GSM_INCLUDES_PATH . '/payments/class-gsm-paypal.php';
require_once GSM_INCLUDES_PATH . '/payments/class-gsm-wallet.php';

/**
 * Notifications
 */
require_once GSM_INCLUDES_PATH . '/notifications/class-gsm-notification-queue.php';
require_once GSM_INCLUDES_PATH . '/notifications/class-gsm-telegram.php';
require_once GSM_INCLUDES_PATH . '/notifications/class-gsm-whatsapp.php';

/**
 * User Account Functions
 */
require_once GSM_INCLUDES_PATH . '/class-gsm-user-account.php';
require_once GSM_INCLUDES_PATH . '/class-gsm-order-manager.php';
require_once GSM_INCLUDES_PATH . '/class-gsm-ticket-manager.php';

/**
 * AJAX Handlers
 */
require_once GSM_INCLUDES_PATH . '/ajax-handlers.php';

/**
 * Template Functions
 */
require_once GSM_INCLUDES_PATH . '/template-functions.php';

/**
 * Custom Roles and Capabilities
 */
function gsm_add_custom_roles() {
    // Only run on theme activation
    if (get_option('gsm_roles_version') !== GSM_THEME_VERSION) {

        // Add custom roles
        add_role('gsm_dealer', __('Dealer', 'gsm-services'), array(
            'read' => true,
            'edit_posts' => false,
            'delete_posts' => false,
            'view_gsm_services' => true,
            'create_gsm_orders' => true,
            'view_own_orders' => true,
            'create_tickets' => true,
        ));

        add_role('gsm_partner', __('Partner', 'gsm-services'), array(
            'read' => true,
            'edit_posts' => false,
            'delete_posts' => false,
            'view_gsm_services' => true,
            'create_gsm_orders' => true,
            'view_own_orders' => true,
            'create_tickets' => true,
            'view_commissions' => true,
        ));

        // Add capabilities to admin
        $admin = get_role('administrator');
        $admin->add_cap('manage_gsm_services');
        $admin->add_cap('manage_gsm_orders');
        $admin->add_cap('manage_gsm_tickets');
        $admin->add_cap('manage_gsm_settings');
        $admin->add_cap('view_gsm_audit_logs');

        update_option('gsm_roles_version', GSM_THEME_VERSION);
    }
}
add_action('after_switch_theme', 'gsm_add_custom_roles');

/**
 * Remove default WordPress headers for security
 */
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');

/**
 * Disable XML-RPC for security
 */
add_filter('xmlrpc_enabled', '__return_false');

/**
 * Remove WordPress version from scripts and styles
 */
function gsm_remove_version_scripts_styles($src) {
    if (strpos($src, 'ver=')) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}
add_filter('style_loader_src', 'gsm_remove_version_scripts_styles', 9999);
add_filter('script_loader_src', 'gsm_remove_version_scripts_styles', 9999);

/**
 * Security Headers
 */
function gsm_add_security_headers() {
    if (!is_admin()) {
        header('X-Frame-Options: DENY');
        header('X-Content-Type-Options: nosniff');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://js.stripe.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; frame-src https://js.stripe.com; connect-src 'self' https://api.stripe.com;");

        // HSTS (only when HTTPS is enabled)
        if (is_ssl()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
        }
    }
}
add_action('send_headers', 'gsm_add_security_headers');

/**
 * Limit login attempts (simple implementation)
 */
function gsm_check_login_attempts($user, $username, $password) {
    $transient_key = 'gsm_login_attempts_' . md5($username . $_SERVER['REMOTE_ADDR']);
    $attempts = get_transient($transient_key);

    if ($attempts && $attempts >= 5) {
        return new WP_Error('too_many_attempts', __('Too many failed login attempts. Please try again in 15 minutes.', 'gsm-services'));
    }

    return $user;
}
add_filter('authenticate', 'gsm_check_login_attempts', 30, 3);

/**
 * Record failed login attempts
 */
function gsm_record_failed_login($username) {
    $transient_key = 'gsm_login_attempts_' . md5($username . $_SERVER['REMOTE_ADDR']);
    $attempts = get_transient($transient_key);
    $attempts = $attempts ? $attempts + 1 : 1;

    set_transient($transient_key, $attempts, 15 * MINUTE_IN_SECONDS);

    // Log to audit trail
    gsm_log_security_event('failed_login', array(
        'username' => $username,
        'ip' => $_SERVER['REMOTE_ADDR'],
        'attempts' => $attempts,
    ));
}
add_action('wp_login_failed', 'gsm_record_failed_login');

/**
 * Clear login attempts on successful login
 */
function gsm_clear_login_attempts($user_login, $user) {
    $transient_key = 'gsm_login_attempts_' . md5($user_login . $_SERVER['REMOTE_ADDR']);
    delete_transient($transient_key);
}
add_action('wp_login', 'gsm_clear_login_attempts', 10, 2);

/**
 * Audit logging function
 */
function gsm_log_security_event($action, $details = array()) {
    global $wpdb;

    $table_name = $wpdb->prefix . 'gsm_audit_logs';

    $wpdb->insert($table_name, array(
        'user_id' => get_current_user_id(),
        'action' => sanitize_text_field($action),
        'details' => maybe_serialize($details),
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
        'created_at' => current_time('mysql'),
    ));
}

/**
 * Create custom database tables on theme activation
 */
function gsm_create_custom_tables() {
    global $wpdb;

    $charset_collate = $wpdb->get_charset_collate();

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // Audit logs table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gsm_audit_logs (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) DEFAULT NULL,
        action varchar(100) NOT NULL,
        details longtext,
        ip_address varchar(45) NOT NULL,
        user_agent varchar(255),
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY action (action),
        KEY created_at (created_at)
    ) $charset_collate;";
    dbDelta($sql);

    // 2FA secrets table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gsm_2fa_secrets (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        secret varchar(32) NOT NULL,
        enabled tinyint(1) DEFAULT 0,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql);

    // Backup codes table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gsm_backup_codes (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        code_hash varchar(64) NOT NULL,
        used tinyint(1) DEFAULT 0,
        used_at datetime DEFAULT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";
    dbDelta($sql);

    // Wallet transactions table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gsm_wallet_transactions (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        amount decimal(10,2) NOT NULL,
        type varchar(20) NOT NULL,
        description text,
        reference_id bigint(20) DEFAULT NULL,
        balance_before decimal(10,2) NOT NULL,
        balance_after decimal(10,2) NOT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY created_at (created_at)
    ) $charset_collate;";
    dbDelta($sql);

    // Notification queue table
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}gsm_notification_queue (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        type varchar(20) NOT NULL,
        recipient varchar(255) NOT NULL,
        message text NOT NULL,
        metadata longtext,
        status varchar(20) DEFAULT 'pending',
        retry_count int(11) DEFAULT 0,
        max_retries int(11) DEFAULT 3,
        last_error text,
        sent_at datetime DEFAULT NULL,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY status (status),
        KEY type (type)
    ) $charset_collate;";
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'gsm_create_custom_tables');

/**
 * Cron schedules for notifications and cleanup
 */
function gsm_add_cron_schedules($schedules) {
    $schedules['every_minute'] = array(
        'interval' => 60,
        'display' => __('Every Minute', 'gsm-services'),
    );
    return $schedules;
}
add_filter('cron_schedules', 'gsm_add_cron_schedules');

/**
 * Schedule cron jobs
 */
function gsm_schedule_cron_jobs() {
    if (!wp_next_scheduled('gsm_process_notifications')) {
        wp_schedule_event(time(), 'every_minute', 'gsm_process_notifications');
    }

    if (!wp_next_scheduled('gsm_cleanup_old_logs')) {
        wp_schedule_event(time(), 'daily', 'gsm_cleanup_old_logs');
    }
}
add_action('wp', 'gsm_schedule_cron_jobs');

/**
 * Process notification queue (cron job)
 */
function gsm_process_notification_queue() {
    if (class_exists('GSM_Notification_Queue')) {
        GSM_Notification_Queue::process_pending();
    }
}
add_action('gsm_process_notifications', 'gsm_process_notification_queue');

/**
 * Cleanup old logs (cron job)
 */
function gsm_cleanup_old_audit_logs() {
    global $wpdb;

    $retention_days = get_option('gsm_audit_log_retention', 90);
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->prefix}gsm_audit_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
        $retention_days
    ));
}
add_action('gsm_cleanup_old_logs', 'gsm_cleanup_old_audit_logs');

/**
 * Helper function to check user capability
 */
function gsm_user_can($capability) {
    return current_user_can($capability);
}

/**
 * Get user balance
 */
function gsm_get_user_balance($user_id = null) {
    if (!$user_id) {
        $user_id = get_current_user_id();
    }

    return (float) get_user_meta($user_id, 'gsm_wallet_balance', true);
}

/**
 * Format price
 */
function gsm_format_price($amount) {
    $currency_symbol = get_option('gsm_currency_symbol', '$');
    return $currency_symbol . number_format($amount, 2);
}

/**
 * Sanitize and escape functions for security
 */
function gsm_sanitize_text($text) {
    return sanitize_text_field($text);
}

function gsm_escape_html($text) {
    return esc_html($text);
}

function gsm_escape_url($url) {
    return esc_url($url);
}
