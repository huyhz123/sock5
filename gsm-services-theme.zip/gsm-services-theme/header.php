<?php
/**
 * The header template
 *
 * @package GSM_Services_Pro
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="container">
        <div class="site-branding">
            <?php if (has_custom_logo()) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="site-title">
                    <?php bloginfo('name'); ?>
                </a>
            <?php endif; ?>
        </div>

        <nav class="main-navigation">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'menu_class' => 'primary-menu',
                'container' => false,
                'fallback_cb' => false,
            ));
            ?>

            <?php if (is_user_logged_in()) : ?>
                <div class="user-menu">
                    <a href="<?php echo esc_url(home_url('/account')); ?>">
                        <?php _e('My Account', 'gsm-services'); ?>
                    </a>
                    <span class="balance">
                        <?php echo gsm_format_price(gsm_get_user_balance()); ?>
                    </span>
                    <a href="<?php echo wp_logout_url(home_url()); ?>">
                        <?php _e('Logout', 'gsm-services'); ?>
                    </a>
                </div>
            <?php else : ?>
                <div class="user-menu">
                    <a href="<?php echo wp_login_url(); ?>"><?php _e('Login', 'gsm-services'); ?></a>
                    <a href="<?php echo wp_registration_url(); ?>"><?php _e('Register', 'gsm-services'); ?></a>
                </div>
            <?php endif; ?>
        </nav>
    </div>
</header>

<?php
// Display admin notice or flash messages
if (isset($_SESSION['gsm_notice'])) {
    $notice = $_SESSION['gsm_notice'];
    echo '<div class="alert alert-' . esc_attr($notice['type']) . '">' . esc_html($notice['message']) . '</div>';
    unset($_SESSION['gsm_notice']);
}
?>
