# GSM Services Platform

**Enterprise-Grade PHP Platform with Advanced Security Hardening**

A complete, secure PHP application for GSM services (IMEI check, unlock, FRP removal), featuring:
- ✅ 2FA/TOTP authentication
- ✅ Role-Based Access Control (RBAC)
- ✅ CSRF protection on all forms
- ✅ Rate limiting & brute-force protection
- ✅ Comprehensive audit logging
- ✅ Encrypted sensitive data
- ✅ Notification queue (Telegram/WhatsApp)
- ✅ Wallet/balance system
- ✅ Ticket support system
- ✅ Multi-language support

---

## 📋 Table of Contents

1. [Requirements](#requirements)
2. [Installation](#installation)
3. [Security Configuration](#security-configuration)
4. [First-Time Setup](#first-time-setup)
5. [Enabling 2FA](#enabling-2fa)
6. [Notification Setup](#notification-setup)
7. [Cron Jobs](#cron-jobs)
8. [Security Hardening Checklist](#security-hardening-checklist)
9. [Testing & Validation](#testing--validation)
10. [Deployment Guide](#deployment-guide)
11. [Troubleshooting](#troubleshooting)

---

## ⚙️ Requirements

### Minimum Requirements
- **PHP**: 7.4 - 8.3
- **Database**: MySQL 5.7+ or MariaDB 10.3+
- **Web Server**: Apache 2.4+ (with mod_rewrite) or Nginx
- **PHP Extensions**:
  - `pdo_mysql` - Database access
  - `openssl` - Encryption & HTTPS
  - `gd` - QR code generation
  - `mbstring` - Multibyte string support
  - `curl` - External API calls
  - `json` - JSON handling
  - `session` - Session management

### Recommended
- PHP 8.1+ for better performance and security
- Argon2 password hashing (compile PHP with `--with-password-argon2`)
- Redis for session storage (optional)
- ClamAV for virus scanning uploaded files (optional)

---

## 🚀 Installation

### Step 1: Upload Files

```bash
# Extract the ZIP file to your web server
unzip gsm-services-platform.zip -d /var/www/html/gsm-platform
cd /var/www/html/gsm-platform
```

### Step 2: Set File Permissions

```bash
# Set ownership (adjust user/group for your server)
chown -R www-data:www-data .

# Set directory permissions
find . -type d -exec chmod 755 {} \;

# Set file permissions
find . -type f -exec chmod 644 {} \;

# Make scripts executable
chmod +x cron/*.php scripts/*.php

# Secure sensitive directories (writable by web server)
chmod 775 uploads/ logs/
chmod 755 config/

# Create backups directory
mkdir -p backups
chmod 755 backups
```

### Step 3: Create Database

```bash
# Login to MySQL
mysql -u root -p

# Create database
CREATE DATABASE gsm_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Create database user (CHANGE PASSWORD!)
CREATE USER 'gsm_user'@'localhost' IDENTIFIED BY 'YOUR_STRONG_PASSWORD_HERE';

# Grant permissions (least privilege)
GRANT SELECT, INSERT, UPDATE, DELETE ON gsm_platform.* TO 'gsm_user'@'localhost';

FLUSH PRIVILEGES;
EXIT;
```

### Step 4: Import Database Schema

```bash
mysql -u gsm_user -p gsm_platform < database.sql
```

### Step 5: Configure Environment

```bash
# Copy .env.sample to .env
cp .env.sample .env

# Edit .env with your settings
nano .env
```

**CRITICAL: Update these values in .env:**

```env
# Database
DB_HOST=localhost
DB_NAME=gsm_platform
DB_USER=gsm_user
DB_PASS=YOUR_STRONG_PASSWORD_HERE  # Change this!

# Security (GENERATE NEW KEY!)
ENCRYPTION_KEY=YOUR_32_CHAR_RANDOM_STRING_HERE  # Generate: openssl rand -base64 32

# Site
SITE_URL=https://yourdomain.com
ADMIN_PATH=admin  # Change to non-guessable path (e.g., panel-2k3j4)

# HTTPS
FORCE_HTTPS=true
ENABLE_HSTS=true
```

### Step 6: Generate Encryption Key

```bash
# Generate a strong 32-character encryption key
openssl rand -base64 32
# Copy the output to .env -> ENCRYPTION_KEY
```

### Step 7: Verify Apache/Nginx Configuration

**For Apache:**

Ensure `mod_rewrite` is enabled:
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

**For Nginx:**

Add this to your server block:
```nginx
location / {
    try_files $uri $uri/ /index.php?$query_string;
}

location ~ \.php$ {
    fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
    fastcgi_index index.php;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    include fastcgi_params;
}

# Block access to sensitive files
location ~ /\.(env|git|htaccess) {
    deny all;
}
```

---

## 🔒 Security Configuration

### 1. Change Default Admin Password

**IMPORTANT:** The default admin credentials are:
- **Username**: `admin`
- **Password**: `__CHANGE_ME__`

**Login immediately and change the password:**
1. Go to `https://yourdomain.com/login`
2. Login with admin / `__CHANGE_ME__`
3. Go to Profile → Change Password
4. Set a strong password (10+ chars, uppercase, lowercase, digit, symbol)

### 2. Enable 2FA for Admin

**MANDATORY for super_admin role:**
1. Login as admin
2. Go to Profile → Security Settings
3. Click "Setup 2FA"
4. Scan QR code with Google Authenticator / Authy
5. **SAVE BACKUP CODES** in a secure location
6. Enter verification code to enable

### 3. Configure Admin IP Whitelist (Optional but Recommended)

In `.env`:
```env
ADMIN_IP_WHITELIST=203.0.113.5,203.0.113.10
```

Leave empty to allow all IPs.

### 4. Change Admin Panel Path

In `.env`:
```env
ADMIN_PATH=secret-panel-xk2j9  # Use random string
```

This prevents automated attacks on `/admin`.

### 5. Set Strong Password Policy

Already enforced in code:
- Minimum 10 characters
- Requires uppercase + lowercase + digit + symbol
- Blocks common passwords
- Account lockout after 5 failed attempts (15 min)

---

## 🎯 First-Time Setup

### Test Login

1. Navigate to: `https://yourdomain.com`
2. Click "Login"
3. Use default credentials (CHANGE IMMEDIATELY):
   - Username: `admin`
   - Password: `__CHANGE_ME__`

### Create Regular User

1. Click "Register"
2. Fill in username, email, password
3. Login with new account

### Access Admin Panel

1. Login as admin
2. Navigate to: `https://yourdomain.com/YOUR_ADMIN_PATH`
3. Manage users, services, orders, tickets, settings

---

## 🔐 Enabling 2FA

### For Users

1. Login to your account
2. Go to **Profile → Security Settings**
3. Click **"Setup 2FA"**
4. **Scan QR code** with:
   - Google Authenticator (Android/iOS)
   - Authy
   - Microsoft Authenticator
   - Any TOTP-compatible app
5. **Save backup codes** - print or store securely
6. Enter 6-digit code to verify

### For Admin (Forced 2FA)

If `FORCE_ADMIN_2FA=true` in `.env`:
- Super admins **MUST** enable 2FA to access admin panel
- System will redirect to 2FA setup on first admin panel access

### Recovery

Lost your authenticator device?
1. Use one of your **backup codes** to login
2. Go to Security Settings
3. Disable 2FA (requires backup code)
4. Re-enable 2FA with new device

---

## 📲 Notification Setup

### Telegram Bot

1. **Create Bot:**
   - Message @BotFather on Telegram
   - Send `/newbot`
   - Follow instructions, get **BOT_TOKEN**

2. **Get Chat ID:**
   ```bash
   # Send a message to your bot, then run:
   curl https://api.telegram.org/bot<BOT_TOKEN>/getUpdates
   # Look for "chat":{"id":123456789}
   ```

3. **Configure in .env:**
   ```env
   TELEGRAM_BOT_TOKEN=123456:ABCdefGHIjklMNOpqrsTUVwxyz
   TELEGRAM_CHAT_ID=123456789
   ```

### WhatsApp Business API

1. **Setup WhatsApp Cloud API:**
   - Go to https://developers.facebook.com/
   - Create Business App
   - Add WhatsApp product
   - Get **Phone Number ID** and **Access Token**

2. **Configure in .env:**
   ```env
   WHATSAPP_PHONE_ID=1234567890123
   WHATSAPP_TOKEN=EAABcDEFghiJKlmnOPQrsTUVwxYz
   ```

### Test Notifications

Go to Admin Panel → Settings → Test Notification

---

## ⏰ Cron Jobs

### Setup Cron

```bash
crontab -e
```

Add these lines:

```cron
# Process notification queue (every minute)
* * * * * php /var/www/html/gsm-platform/cron/send_notifications.php >> /var/www/html/gsm-platform/logs/cron.log 2>&1

# Database backup (daily at 2 AM)
0 2 * * * php /var/www/html/gsm-platform/cron/backup_db.php >> /var/www/html/gsm-platform/logs/backup.log 2>&1

# Clean old logs (weekly)
0 3 * * 0 find /var/www/html/gsm-platform/logs -name "*.log" -mtime +30 -delete
```

### Verify Cron is Running

```bash
# Check logs
tail -f logs/cron.log
tail -f logs/backup.log
```

---

## 🛡️ Security Hardening Checklist

### Pre-Deployment Checklist

- [ ] Changed default admin password
- [ ] Enabled 2FA for all admin accounts
- [ ] Generated new encryption key (32+ chars)
- [ ] Updated all API tokens in .env
- [ ] Changed admin panel path from default
- [ ] Set FORCE_HTTPS=true
- [ ] Set ENABLE_HSTS=true (after SSL installed)
- [ ] Set DISPLAY_ERRORS=false
- [ ] Configured ADMIN_IP_WHITELIST (if applicable)
- [ ] Set proper file permissions (755 dirs, 644 files)
- [ ] .env file is NOT in web root
- [ ] Uploaded .htaccess files are active
- [ ] Database user has least privileges (no GRANT, CREATE USER)
- [ ] Ran `php scripts/security_check.php`
- [ ] Tested CSRF tokens on all forms
- [ ] Verified rate limiting works (try 6 failed logins)
- [ ] Checked audit logs are recording
- [ ] Configured cron jobs
- [ ] Tested backup script
- [ ] Set up monitoring/alerting

### SSL/HTTPS Setup

#### Using Let's Encrypt (Recommended)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-apache

# Get certificate
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com

# Auto-renewal (add to cron)
0 0 1 * * certbot renew --quiet
```

#### Enable HSTS

After SSL is working:
1. In `.env`: `ENABLE_HSTS=true`
2. Uncomment HSTS in `public/.htaccess`:
   ```apache
   Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
   ```

### Firewall Configuration

```bash
# UFW (Ubuntu)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 22/tcp
sudo ufw enable

# Fail2Ban for SSH brute-force
sudo apt install fail2ban
```

### Database Security

```bash
# Secure MySQL
mysql_secure_installation

# Remove test database
mysql -u root -p -e "DROP DATABASE IF EXISTS test;"

# Check privileges
mysql -u root -p -e "SHOW GRANTS FOR 'gsm_user'@'localhost';"
```

---

## ✅ Testing & Validation

### 1. Run PHP Syntax Check

```bash
find . -name "*.php" -exec php -l {} \; | grep -v "No syntax errors"
```

### 2. Run Security Check Script

```bash
php scripts/security_check.php
```

**Expected Output:**
```
========================================
GSM Services Platform - Security Check
========================================

PASSED CHECKS (X):
  ✓ .env file exists
  ✓ Encryption key configured
  ✓ Database password set
  ...

WARNINGS (0):
  None

CRITICAL ISSUES (0):
  None

========================================
✓ All security checks passed!
```

### 3. Test Key Features

- [ ] User registration works
- [ ] Login with rate limiting (5 attempts = lockout)
- [ ] CSRF protection (remove token from form, submit fails)
- [ ] 2FA setup and verification
- [ ] Backup codes work
- [ ] Session timeout after 30 min inactivity
- [ ] Admin panel requires authentication
- [ ] Audit logs record actions
- [ ] File upload restrictions work
- [ ] Notifications queue (check Telegram/WhatsApp)

---

## 🚀 Deployment Guide

### Production Deployment Steps

1. **Environment Check**
   ```bash
   php -v  # PHP 7.4+
   mysql --version  # MySQL 5.7+
   apache2 -v  # or nginx -v
   ```

2. **Upload & Configure**
   - Upload files to production server
   - Set permissions (see Installation)
   - Configure .env for production
   - Import database

3. **Security Hardening**
   - Run through Security Hardening Checklist
   - Enable firewall
   - Install SSL certificate
   - Configure HSTS

4. **Testing**
   - Run security_check.php
   - Test login/2FA
   - Verify cron jobs
   - Check logs

5. **Monitoring**
   - Set up log rotation
   - Monitor `logs/error.log`
   - Check backup files daily
   - Monitor Telegram alerts

### Performance Optimization

**PHP-FPM:**
```ini
; /etc/php/8.1/fpm/php.ini
memory_limit = 256M
max_execution_time = 60
opcache.enable = 1
opcache.memory_consumption = 128
```

**Database:**
```sql
-- Add indexes for performance
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
CREATE INDEX idx_audit_created ON audit_logs(created_at);
```

---

## 🐛 Troubleshooting

### Issue: Can't login / Session errors

**Solution:**
```bash
# Check session directory permissions
ls -la /var/lib/php/sessions
sudo chown www-data:www-data /var/lib/php/sessions

# Clear sessions
rm -rf /var/lib/php/sessions/*
```

### Issue: CSRF token validation fails

**Solution:**
1. Ensure session is started before form rendered
2. Check session.cookie_secure setting matches HTTPS
3. Verify browser accepts cookies

### Issue: 2FA QR code not showing

**Solution:**
1. Ensure `gd` extension is installed: `php -m | grep gd`
2. Check PHP error logs
3. Fallback: use manual entry (secret key displayed)

### Issue: Notifications not sending

**Solution:**
```bash
# Check cron is running
crontab -l

# Test manually
php cron/send_notifications.php

# Check logs
tail -f logs/app.log
tail -f logs/error.log

# Verify credentials in .env
```

### Issue: Database connection failed

**Solution:**
1. Verify credentials in .env
2. Check MySQL is running: `sudo systemctl status mysql`
3. Test connection: `mysql -u gsm_user -p`
4. Check user permissions: `SHOW GRANTS FOR 'gsm_user'@'localhost';`

### Issue: "Too many redirects"

**Solution:**
- Check FORCE_HTTPS setting
- Verify SSL is properly configured
- Check .htaccess rewrite rules

---

## 📚 Additional Information

### File Structure

```
gsm-services-platform/
├── .env.sample          # Environment template
├── .htaccess           # Root protection
├── README.md           # This file
├── database.sql        # Database schema
├── app/
│   ├── Controllers/    # Application controllers
│   ├── Models/         # Data models
│   ├── Middleware/     # Auth, RBAC middleware
│   └── Views/          # HTML templates
├── config/
│   └── config.php      # Main configuration
├── core/
│   ├── Database.php    # PDO wrapper
│   ├── Security.php    # Security utilities
│   ├── Session.php     # Session management
│   ├── Router.php      # URL routing
│   ├── Logger.php      # Logging system
│   ├── TOTP.php        # 2FA implementation
│   └── QRCode.php      # QR code generator
├── cron/
│   ├── send_notifications.php  # Notification processor
│   └── backup_db.php          # Database backup
├── logs/               # Application logs
├── modules/
│   └── Notifications/  # Notification queue
├── public/
│   ├── .htaccess      # Web server config
│   └── index.php      # Entry point
├── scripts/
│   └── security_check.php  # Security validator
├── uploads/           # User uploads (protected)
└── lang/              # Language files
```

### Key Rotation

**Rotate Encryption Key:**
1. Generate new key: `openssl rand -base64 32`
2. Create migration script to re-encrypt data
3. Update .env with new key
4. Run migration

**Rotate 2FA Secret:**
1. User: Disable 2FA → Re-enable with new secret
2. Admin can reset user 2FA from admin panel

### Support & Contribution

For issues, feature requests, or contributions, please contact the development team.

---

## 📄 License & Credits

**GSM Services Platform** - Enterprise-Grade PHP Application
Developed with OWASP security best practices.

All rights reserved. For commercial use, please obtain a license.

---

## 🎓 Security Best Practices Applied

✅ **Authentication**
- Bcrypt/Argon2 password hashing
- Password complexity enforcement
- Account lockout (5 attempts / 15 min)
- Secure password reset with tokens

✅ **Multi-Factor Authentication**
- TOTP (RFC 6238) implementation
- QR code generation
- Backup codes
- Recovery mechanisms

✅ **Authorization**
- RBAC with granular permissions
- Session validation
- CSRF protection
- Rate limiting

✅ **Data Protection**
- PDO prepared statements (SQL injection prevention)
- XSS protection (output escaping)
- Input validation
- Encryption for sensitive data

✅ **Infrastructure**
- HTTPS enforcement
- HSTS headers
- CSP headers
- Secure session configuration
- File upload restrictions

✅ **Monitoring**
- Comprehensive audit logging
- Error logging
- Real-time alerts (Telegram)
- Security event tracking

---

**🔒 Stay Secure! Keep the platform updated and monitor logs regularly.**
