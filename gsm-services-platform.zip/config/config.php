<?php
/**
 * Main Configuration File
 * Loads environment variables from .env file
 */

// Load environment variables
function loadEnv($file) {
    if (!file_exists($file)) {
        die("Configuration file not found. Please copy .env.sample to .env and configure.");
    }

    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;

        list($key, $value) = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);

        if (!array_key_exists($key, $_ENV)) {
            $_ENV[$key] = $value;
            putenv("$key=$value");
        }
    }
}

// Load .env file
$envFile = dirname(__DIR__) . '/.env';
if (file_exists($envFile)) {
    loadEnv($envFile);
}

// Define constants
define('ROOT_PATH', dirname(__DIR__));
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('APP_PATH', ROOT_PATH . '/app');
define('CORE_PATH', ROOT_PATH . '/core');
define('MODULES_PATH', ROOT_PATH . '/modules');
define('UPLOAD_PATH', ROOT_PATH . '/uploads');
define('LOG_PATH', ROOT_PATH . '/logs');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('LANG_PATH', ROOT_PATH . '/lang');

// Database configuration
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'gsm_platform');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', getenv('DB_CHARSET') ?: 'utf8mb4');

// Site configuration
define('SITE_NAME', getenv('SITE_NAME') ?: 'GSM Services Platform');
define('SITE_URL', getenv('SITE_URL') ?: 'http://localhost');
define('ADMIN_PATH', getenv('ADMIN_PATH') ?: 'admin');
define('TIMEZONE', getenv('TIMEZONE') ?: 'UTC');

// Security configuration
define('SESSION_LIFETIME', (int)getenv('SESSION_LIFETIME') ?: 1800);
define('ENCRYPTION_KEY', getenv('ENCRYPTION_KEY') ?: '__CHANGE_ME__');
define('CSRF_TOKEN_LIFETIME', (int)getenv('CSRF_TOKEN_LIFETIME') ?: 3600);
define('ENABLE_2FA', getenv('ENABLE_2FA') === 'true');
define('FORCE_ADMIN_2FA', getenv('FORCE_ADMIN_2FA') === 'true');

// HTTPS configuration
define('FORCE_HTTPS', getenv('FORCE_HTTPS') === 'true');
define('ENABLE_HSTS', getenv('ENABLE_HSTS') === 'true');

// Admin IP whitelist
define('ADMIN_IP_WHITELIST', getenv('ADMIN_IP_WHITELIST') ?: '');

// Rate limiting
define('RATE_LIMIT_LOGIN_ATTEMPTS', (int)getenv('RATE_LIMIT_LOGIN_ATTEMPTS') ?: 5);
define('RATE_LIMIT_LOGIN_WINDOW', (int)getenv('RATE_LIMIT_LOGIN_WINDOW') ?: 900);
define('RATE_LIMIT_API_REQUESTS', (int)getenv('RATE_LIMIT_API_REQUESTS') ?: 60);
define('RATE_LIMIT_API_WINDOW', (int)getenv('RATE_LIMIT_API_WINDOW') ?: 60);

// File upload
define('MAX_UPLOAD_SIZE', (int)getenv('MAX_UPLOAD_SIZE') ?: 5242880);
define('ALLOWED_IMAGE_TYPES', explode(',', getenv('ALLOWED_IMAGE_TYPES') ?: 'jpg,jpeg,png,webp'));

// Notifications
define('TELEGRAM_BOT_TOKEN', getenv('TELEGRAM_BOT_TOKEN') ?: '');
define('TELEGRAM_CHAT_ID', getenv('TELEGRAM_CHAT_ID') ?: '');
define('WHATSAPP_API_URL', getenv('WHATSAPP_API_URL') ?: 'https://graph.facebook.com/v18.0');
define('WHATSAPP_PHONE_ID', getenv('WHATSAPP_PHONE_ID') ?: '');
define('WHATSAPP_TOKEN', getenv('WHATSAPP_TOKEN') ?: '');

// Payment gateways
define('STRIPE_SECRET_KEY', getenv('STRIPE_SECRET_KEY') ?: '');
define('STRIPE_PUBLIC_KEY', getenv('STRIPE_PUBLIC_KEY') ?: '');
define('PAYPAL_CLIENT_ID', getenv('PAYPAL_CLIENT_ID') ?: '');
define('PAYPAL_SECRET', getenv('PAYPAL_SECRET') ?: '');
define('PAYPAL_MODE', getenv('PAYPAL_MODE') ?: 'sandbox');

// External APIs
define('GSM_API_URL', getenv('GSM_API_URL') ?: '');
define('GSM_API_KEY', getenv('GSM_API_KEY') ?: '');

// Backup
define('BACKUP_PATH', ROOT_PATH . (getenv('BACKUP_PATH') ?: '/backups'));
define('BACKUP_RETENTION_DAYS', (int)getenv('BACKUP_RETENTION_DAYS') ?: 30);

// Logging
define('LOG_LEVEL', getenv('LOG_LEVEL') ?: 'INFO');
$errorReporting = getenv('ERROR_REPORTING');
if ($errorReporting === 'E_ALL' || empty($errorReporting)) {
    define('ERROR_REPORTING_LEVEL', E_ALL);
} else {
    define('ERROR_REPORTING_LEVEL', (int)$errorReporting);
}
define('DISPLAY_ERRORS', getenv('DISPLAY_ERRORS') === 'true');

// Maintenance mode
define('MAINTENANCE_MODE', getenv('MAINTENANCE_MODE') === 'true');
define('MAINTENANCE_MESSAGE', getenv('MAINTENANCE_MESSAGE') ?: 'Site under maintenance');

// Set timezone
date_default_timezone_set(TIMEZONE);

// Error reporting
error_reporting(ERROR_REPORTING_LEVEL);
ini_set('display_errors', DISPLAY_ERRORS ? '1' : '0');

// Only set headers and sessions when not running from CLI
if (php_sapi_name() !== 'cli') {
    // Session configuration - SECURE
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_secure', FORCE_HTTPS ? '1' : '0');
    ini_set('session.cookie_samesite', 'Strict');
    ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
    ini_set('session.use_strict_mode', '1');

    // Security headers
    if (FORCE_HTTPS && !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        if (ENABLE_HSTS) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
        }
    }

    // Content Security Policy
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; img-src 'self' data: https:; font-src 'self' https://cdnjs.cloudflare.com; frame-ancestors 'none';");
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

    // HTTPS redirect
    if (FORCE_HTTPS && (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off')) {
        $redirect = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: ' . $redirect);
        exit();
    }
}

// Autoloader
spl_autoload_register(function ($class) {
    $paths = [
        CORE_PATH . '/',
        APP_PATH . '/Controllers/',
        APP_PATH . '/Models/',
        APP_PATH . '/Middleware/',
        MODULES_PATH . '/'
    ];

    foreach ($paths as $path) {
        $file = $path . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Include core files
require_once CORE_PATH . '/Database.php';
require_once CORE_PATH . '/Security.php';
require_once CORE_PATH . '/Session.php';
require_once CORE_PATH . '/Router.php';
require_once CORE_PATH . '/Logger.php';
require_once CORE_PATH . '/TOTP.php';
require_once CORE_PATH . '/QRCode.php';

return [
    'db' => [
        'host' => DB_HOST,
        'name' => DB_NAME,
        'user' => DB_USER,
        'pass' => DB_PASS,
        'charset' => DB_CHARSET
    ],
    'site' => [
        'name' => SITE_NAME,
        'url' => SITE_URL
    ]
];
