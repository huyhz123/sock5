<?php
/**
 * Authentication Controller
 * Handles login, register, 2FA verification, logout
 * With CSRF protection and rate limiting
 */

class AuthController {
    private $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    public function loginForm() {
        if (Session::isLoggedIn()) {
            Router::redirect('/dashboard');
        }
        require APP_PATH . '/Views/auth/login.php';
    }

    public function login() {
        // CSRF validation
        if (!isset($_POST['csrf_token']) || !Security::validateCSRFToken($_POST['csrf_token'])) {
            Session::setFlash('error', 'Invalid request. Please try again.', 'error');
            Router::redirect('/login');
        }

        $credential = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        // Rate limiting
        $rateLimitKey = 'login:' . Security::getClientIP();
        if (!Security::checkRateLimit($rateLimitKey, RATE_LIMIT_LOGIN_ATTEMPTS, RATE_LIMIT_LOGIN_WINDOW)) {
            Session::setFlash('error', 'Too many login attempts. Please try again later.', 'error');
            Router::redirect('/login');
        }

        // Check account lockout
        if (Security::isAccountLocked($credential)) {
            Session::setFlash('error', 'Account locked due to multiple failed login attempts. Try again in 15 minutes.', 'error');
            Router::redirect('/login');
        }

        // Find user
        $user = $this->userModel->findByCredential($credential);

        if (!$user || !Security::verifyPassword($password, $user['password'])) {
            Security::recordFailedLogin($credential, Security::getClientIP());
            Session::setFlash('error', 'Invalid username or password', 'error');
            Router::redirect('/login');
        }

        // Check user status
        if ($user['status'] !== 'active') {
            Session::setFlash('error', 'Account is ' . $user['status'] . '. Contact support.', 'error');
            Router::redirect('/login');
        }

        // Clear failed login attempts
        Security::clearFailedLogins($credential);

        // Check if 2FA is enabled
        if ($user['2fa_enabled']) {
            $_SESSION['temp_user_id'] = $user['id'];
            $_SESSION['requires_2fa'] = true;
            Router::redirect('/verify-2fa');
        } else {
            // Set user session
            Session::setUser($user);

            // Update last login
            $db = Database::getInstance();
            $db->update('users', [
                'last_login' => date('Y-m-d H:i:s'),
                'last_login_ip' => Security::getClientIP()
            ], 'id = :id', [':id' => $user['id']]);

            Router::redirect('/dashboard');
        }
    }

    public function registerForm() {
        if (Session::isLoggedIn()) {
            Router::redirect('/dashboard');
        }
        require APP_PATH . '/Views/auth/register.php';
    }

    public function register() {
        // CSRF validation
        if (!isset($_POST['csrf_token']) || !Security::validateCSRFToken($_POST['csrf_token'])) {
            Session::setFlash('error', 'Invalid request', 'error');
            Router::redirect('/register');
        }

        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        $errors = [];

        // Validation
        if (!Security::validateUsername($username)) {
            $errors[] = 'Invalid username format (3-20 alphanumeric characters)';
        }
        if (!Security::validateEmail($email)) {
            $errors[] = 'Invalid email address';
        }
        if ($password !== $confirmPassword) {
            $errors[] = 'Passwords do not match';
        }

        if (!empty($errors)) {
            Session::setFlash('errors', implode('<br>', $errors), 'error');
            Router::redirect('/register');
        }

        // Create user
        $result = $this->userModel->create([
            'username' => $username,
            'email' => $email,
            'password' => $password
        ]);

        if ($result['success']) {
            Session::setFlash('success', 'Registration successful! Please login.', 'success');
            Router::redirect('/login');
        } else {
            $errorMsg = $result['errors'] ? implode('<br>', $result['errors']) : 'Registration failed';
            Session::setFlash('error', $errorMsg, 'error');
            Router::redirect('/register');
        }
    }

    public function verify2FAForm() {
        if (!isset($_SESSION['temp_user_id']) || !isset($_SESSION['requires_2fa'])) {
            Router::redirect('/login');
        }
        require APP_PATH . '/Views/auth/verify-2fa.php';
    }

    public function verify2FA() {
        if (!isset($_SESSION['temp_user_id'])) {
            Router::redirect('/login');
        }

        // CSRF validation
        if (!isset($_POST['csrf_token']) || !Security::validateCSRFToken($_POST['csrf_token'])) {
            Session::setFlash('error', 'Invalid request', 'error');
            Router::redirect('/verify-2fa');
        }

        $code = trim($_POST['code'] ?? '');
        $userId = $_SESSION['temp_user_id'];

        $user = $this->userModel->findById($userId);
        if (!$user) {
            Router::redirect('/login');
        }

        // Try TOTP verification
        $totp = new TOTP($user['2fa_secret']);
        if ($totp->verifyCode($code)) {
            // Success - complete login
            unset($_SESSION['temp_user_id']);
            unset($_SESSION['requires_2fa']);

            Session::setUser($user);
            Session::mark2FAVerified();

            // Update last login
            $db = Database::getInstance();
            $db->update('users', [
                'last_login' => date('Y-m-d H:i:s'),
                'last_login_ip' => Security::getClientIP()
            ], 'id = :id', [':id' => $user['id']]);

            Router::redirect('/dashboard');
        } else {
            // Try backup code
            if ($this->userModel->verifyBackupCode($userId, $code)) {
                unset($_SESSION['temp_user_id']);
                unset($_SESSION['requires_2fa']);
                Session::setUser($user);
                Session::mark2FAVerified();

                Session::setFlash('warning', 'Backup code used. Please generate new backup codes.', 'warning');
                Router::redirect('/dashboard');
            } else {
                Session::setFlash('error', 'Invalid verification code', 'error');
                Router::redirect('/verify-2fa');
            }
        }
    }

    public function logout() {
        Session::clearUser();
        Router::redirect('/login');
    }
}
