<?php
class ProfileController {
    private $userModel;
    public function __construct() { $this->userModel = new User(); }

    public function index() {
        $user = $this->userModel->findById(Session::getUserId());
        require APP_PATH . '/Views/profile/index.php';
    }

    public function security() {
        $user = $this->userModel->findById(Session::getUserId());
        $qrCode = null;
        $backupCodes = null;

        if (isset($_POST['generate_2fa'])) {
            if (!isset($_POST['csrf_token']) || !Security::validateCSRFToken($_POST['csrf_token'])) {
                Session::setFlash('error', 'Invalid request', 'error');
                Router::redirect('/profile/security');
            }

            $totp = new TOTP();
            $secret = $totp->getSecret();
            $uri = $totp->getProvisioningUri(SITE_NAME, $user['email']);
            $qrCode = QRCode::generate($uri, 200);

            $_SESSION['temp_2fa_secret'] = $secret;
            $backupCodes = TOTP::generateBackupCodes(10);
            $_SESSION['temp_backup_codes'] = $backupCodes;
        }

        require APP_PATH . '/Views/profile/security.php';
    }

    public function enable2FA() {
        if (!isset($_POST['csrf_token']) || !Security::validateCSRFToken($_POST['csrf_token'])) {
            Router::json(['success' => false, 'error' => 'Invalid request'], 400);
        }

        $code = trim($_POST['code'] ?? '');
        $secret = $_SESSION['temp_2fa_secret'] ?? '';

        if (empty($secret)) {
            Router::json(['success' => false, 'error' => 'No 2FA setup in progress'], 400);
        }

        $totp = new TOTP($secret);
        if ($totp->verifyCode($code)) {
            $this->userModel->enable2FA(Session::getUserId(), $secret);

            if (isset($_SESSION['temp_backup_codes'])) {
                $this->userModel->storeBackupCodes(Session::getUserId(), $_SESSION['temp_backup_codes']);
            }

            unset($_SESSION['temp_2fa_secret']);
            unset($_SESSION['temp_backup_codes']);

            Router::json(['success' => true, 'message' => '2FA enabled successfully']);
        } else {
            Router::json(['success' => false, 'error' => 'Invalid verification code'], 400);
        }
    }

    public function disable2FA() {
        if (!isset($_POST['csrf_token']) || !Security::validateCSRFToken($_POST['csrf_token'])) {
            Session::setFlash('error', 'Invalid request', 'error');
            Router::redirect('/profile/security');
        }

        $this->userModel->disable2FA(Session::getUserId());
        Session::setFlash('success', '2FA disabled', 'success');
        Router::redirect('/profile/security');
    }
}
