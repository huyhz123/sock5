<?php
class HomeController {
    public function index() {
        $db = Database::getInstance();
        $categories = $db->query("SELECT * FROM service_categories WHERE status = 'active' ORDER BY sort_order")->fetchAll();
        require APP_PATH . '/Views/home.php';
    }
}
