<?php
/**
 * User Model
 */

class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * Find user by ID
     */
    public function findById($id) {
        return $this->db->query("
            SELECT u.*, p.*
            FROM users u
            LEFT JOIN user_profiles p ON u.id = p.user_id
            WHERE u.id = :id
        ")->bind(':id', $id)->fetch();
    }

    /**
     * Find user by username or email
     */
    public function findByCredential($credential) {
        return $this->db->query("
            SELECT * FROM users
            WHERE username = :credential OR email = :credential
            LIMIT 1
        ")->bind(':credential', $credential)->fetch();
    }

    /**
     * Create new user
     */
    public function create($data) {
        // Validate password
        $passwordValidation = Security::validatePassword($data['password']);
        if (!$passwordValidation['valid']) {
            return ['success' => false, 'errors' => $passwordValidation['errors']];
        }

        // Hash password
        $passwordHash = Security::hashPassword($data['password']);

        try {
            $this->db->beginTransaction();

            // Insert user
            $this->db->insert('users', [
                'username' => $data['username'],
                'email' => $data['email'],
                'password' => $passwordHash,
                'role' => $data['role'] ?? 'user',
                'email_verification_token' => Security::generateToken()
            ]);

            $userId = $this->db->lastInsertId();

            // Create profile
            $this->db->insert('user_profiles', [
                'user_id' => $userId,
                'full_name' => $data['full_name'] ?? null,
                'phone' => $data['phone'] ?? null
            ]);

            $this->db->commit();

            Logger::audit('User created', ['user_id' => $userId, 'username' => $data['username']]);

            return ['success' => true, 'user_id' => $userId];
        } catch (Exception $e) {
            $this->db->rollBack();
            Logger::error('User creation failed: ' . $e->getMessage());
            return ['success' => false, 'error' => 'User creation failed'];
        }
    }

    /**
     * Update user
     */
    public function update($userId, $data) {
        $allowedFields = ['email', 'role', 'status', 'balance'];
        $updateData = [];

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updateData[$field] = $data[$field];
            }
        }

        if (empty($updateData)) {
            return false;
        }

        $result = $this->db->update('users', $updateData, 'id = :id', [':id' => $userId]);

        if ($result) {
            Logger::audit('User updated', ['user_id' => $userId, 'fields' => array_keys($updateData)]);
        }

        return $result;
    }

    /**
     * Update password
     */
    public function updatePassword($userId, $newPassword) {
        $passwordValidation = Security::validatePassword($newPassword);
        if (!$passwordValidation['valid']) {
            return ['success' => false, 'errors' => $passwordValidation['errors']];
        }

        $passwordHash = Security::hashPassword($newPassword);

        $result = $this->db->update('users', [
            'password' => $passwordHash,
            'password_reset_token' => null,
            'password_reset_expires' => null
        ], 'id = :id', [':id' => $userId]);

        if ($result) {
            Logger::audit('Password changed', ['user_id' => $userId]);
        }

        return ['success' => $result];
    }

    /**
     * Enable 2FA for user
     */
    public function enable2FA($userId, $secret) {
        $result = $this->db->update('users', [
            '2fa_enabled' => 1,
            '2fa_secret' => $secret,
            '2fa_verified' => 1
        ], 'id = :id', [':id' => $userId]);

        if ($result) {
            Logger::audit('2FA enabled', ['user_id' => $userId]);
        }

        return $result;
    }

    /**
     * Disable 2FA
     */
    public function disable2FA($userId) {
        $result = $this->db->update('users', [
            '2fa_enabled' => 0,
            '2fa_secret' => null,
            '2fa_verified' => 0
        ], 'id = :id', [':id' => $userId]);

        if ($result) {
            // Delete backup codes
            $this->db->delete('backup_codes', 'user_id = :user_id', [':user_id' => $userId]);
            Logger::audit('2FA disabled', ['user_id' => $userId]);
        }

        return $result;
    }

    /**
     * Store backup codes
     */
    public function storeBackupCodes($userId, $codes) {
        // Delete existing codes
        $this->db->delete('backup_codes', 'user_id = :user_id', [':user_id' => $userId]);

        foreach ($codes as $code) {
            $this->db->insert('backup_codes', [
                'user_id' => $userId,
                'code_hash' => TOTP::hashBackupCode($code)
            ]);
        }
    }

    /**
     * Verify and use backup code
     */
    public function verifyBackupCode($userId, $code) {
        $codeHash = TOTP::hashBackupCode($code);

        $backupCode = $this->db->query("
            SELECT * FROM backup_codes
            WHERE user_id = :user_id AND code_hash = :code_hash AND used = 0
        ")->bind(':user_id', $userId)
          ->bind(':code_hash', $codeHash)
          ->fetch();

        if ($backupCode) {
            // Mark as used
            $this->db->update('backup_codes', [
                'used' => 1,
                'used_at' => date('Y-m-d H:i:s')
            ], 'id = :id', [':id' => $backupCode['id']]);

            Logger::audit('Backup code used', ['user_id' => $userId]);
            return true;
        }

        return false;
    }

    /**
     * Update balance
     */
    public function updateBalance($userId, $amount, $type, $description, $referenceId = null) {
        $user = $this->findById($userId);
        if (!$user) return false;

        $balanceBefore = $user['balance'];
        $balanceAfter = $balanceBefore + $amount;

        if ($balanceAfter < 0) {
            return false; // Insufficient balance
        }

        try {
            $this->db->beginTransaction();

            // Update user balance
            $this->db->update('users', [
                'balance' => $balanceAfter
            ], 'id = :id', [':id' => $userId]);

            // Record transaction
            $this->db->insert('balance_transactions', [
                'user_id' => $userId,
                'amount' => $amount,
                'type' => $type,
                'description' => $description,
                'reference_id' => $referenceId,
                'balance_before' => $balanceBefore,
                'balance_after' => $balanceAfter
            ]);

            $this->db->commit();

            Logger::audit('Balance updated', [
                'user_id' => $userId,
                'amount' => $amount,
                'type' => $type,
                'new_balance' => $balanceAfter
            ]);

            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            Logger::error('Balance update failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Check permission
     */
    public function hasPermission($userId, $permissionName) {
        $user = $this->findById($userId);
        if (!$user) return false;

        // Super admin has all permissions
        if ($user['role'] === 'super_admin') return true;

        $result = $this->db->query("
            SELECT COUNT(*) as count
            FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            WHERE rp.role = :role AND p.name = :permission
        ")->bind(':role', $user['role'])
          ->bind(':permission', $permissionName)
          ->fetch();

        return $result['count'] > 0;
    }
}
