<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= isset($pageTitle) ? Security::escape($pageTitle) . ' - ' : '' ?><?= Security::escape(SITE_NAME) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; background: #f4f4f4; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        header { background: #2c3e50; color: white; padding: 1rem 0; }
        nav { display: flex; justify-content: space-between; align-items: center; }
        nav a { color: white; text-decoration: none; margin: 0 10px; }
        nav a:hover { text-decoration: underline; }
        .alert { padding: 1rem; margin: 1rem 0; border-radius: 4px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert-warning { background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }
        .btn { display: inline-block; padding: 10px 20px; background: #3498db; color: white; text-decoration: none; border: none; border-radius: 4px; cursor: pointer; }
        .btn:hover { background: #2980b9; }
        .btn-danger { background: #e74c3c; }
        .btn-danger:hover { background: #c0392b; }
        .card { background: white; padding: 2rem; margin: 1rem 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        input[type="text"], input[type="email"], input[type="password"], select, textarea { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ddd; border-radius: 4px; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        footer { background: #2c3e50; color: white; text-align: center; padding: 1rem 0; margin-top: 2rem; }
    </style>
</head>
<body>
<header>
    <div class="container">
        <nav>
            <div><a href="/" style="font-size: 1.2em; font-weight: bold;"><?= Security::escape(SITE_NAME) ?></a></div>
            <div>
                <a href="/services">Services</a>
                <?php if (Session::isLoggedIn()): ?>
                    <a href="/dashboard">Dashboard</a>
                    <a href="/orders">Orders</a>
                    <a href="/tickets">Tickets</a>
                    <a href="/profile">Profile</a>
                    <?php if (in_array(Session::getUserRole(), ['super_admin', 'admin'])): ?>
                        <a href="/<?= ADMIN_PATH ?>">Admin</a>
                    <?php endif; ?>
                    <a href="/logout">Logout</a>
                <?php else: ?>
                    <a href="/login">Login</a>
                    <a href="/register">Register</a>
                <?php endif; ?>
            </div>
        </nav>
    </div>
</header>
<div class="container" style="min-height: 70vh;">
    <?php
    // Display flash messages
    if ($flash = Session::getFlash('success')): ?>
        <div class="alert alert-success"><?= Security::escape($flash['message']) ?></div>
    <?php endif;
    if ($flash = Session::getFlash('error')): ?>
        <div class="alert alert-error"><?= Security::escape($flash['message']) ?></div>
    <?php endif;
    if ($flash = Session::getFlash('warning')): ?>
        <div class="alert alert-warning"><?= Security::escape($flash['message']) ?></div>
    <?php endif;
    if ($flash = Session::getFlash('errors')): ?>
        <div class="alert alert-error"><?= $flash['message'] ?></div>
    <?php endif; ?>
