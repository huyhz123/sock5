</div>
<footer>
    <div class="container">
        <p>&copy; <?= date('Y') ?> <?= Security::escape(SITE_NAME) ?>. All rights reserved. | Secure Platform with 2FA & Enterprise-grade Security</p>
    </div>
</footer>
</body>
</html>
