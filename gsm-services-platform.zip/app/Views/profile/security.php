<?php
$pageTitle = 'Security Settings';
include APP_PATH . '/Views/layout/header.php';
?>

<h1>Security Settings</h1>

<div class="card">
    <h2>🔐 Two-Factor Authentication (2FA)</h2>

    <?php if ($user['2fa_enabled']): ?>
        <div class="alert alert-success">
            ✓ 2FA is currently <strong>ENABLED</strong> for your account
        </div>

        <form method="POST" action="/profile/disable-2fa">
            <!-- CSRF Protection -->
            <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to disable 2FA?')">Disable 2FA</button>
        </form>
    <?php else: ?>
        <div class="alert alert-warning">
            ⚠ 2FA is currently <strong>DISABLED</strong>. Enable it for enhanced security.
        </div>

        <?php if (isset($qrCode)): ?>
            <h3>Step 1: Scan QR Code</h3>
            <p>Scan this QR code with Google Authenticator, Authy, or any TOTP app:</p>
            <img src="<?= $qrCode ?>" alt="QR Code" style="max-width: 200px;">

            <h3>Step 2: Save Backup Codes</h3>
            <p><strong>Important:</strong> Save these codes in a safe place. Use them if you lose access to your authenticator app.</p>
            <div class="card" style="background: #f9f9f9; font-family: monospace;">
                <?php foreach ($backupCodes as $code): ?>
                    <?= Security::escape($code) ?><br>
                <?php endforeach; ?>
            </div>

            <h3>Step 3: Verify</h3>
            <form method="POST" action="/profile/enable-2fa" onsubmit="enable2FA(event)">
                <!-- CSRF Protection -->
                <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">

                <div class="form-group">
                    <label>Enter 6-digit code from authenticator:</label>
                    <input type="text" name="code" pattern="[0-9]{6}" required maxlength="6" placeholder="000000">
                </div>
                <button type="submit" class="btn">Enable 2FA</button>
            </form>

            <script>
            function enable2FA(e) {
                e.preventDefault();
                const form = e.target;
                const formData = new FormData(form);

                fetch('/profile/enable-2fa', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert('2FA enabled successfully!');
                        window.location.reload();
                    } else {
                        alert('Error: ' + data.error);
                    }
                })
                .catch(err => alert('Error: ' + err));
            }
            </script>
        <?php else: ?>
            <form method="POST" action="/profile/security">
                <!-- CSRF Protection -->
                <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">
                <button type="submit" name="generate_2fa" class="btn">Setup 2FA</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div class="card">
    <h2>🔑 Change Password</h2>
    <p>Ensure your password meets security requirements: 10+ characters, uppercase, lowercase, digit, symbol</p>
    <form method="POST" action="/profile/change-password">
        <!-- CSRF Protection -->
        <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">

        <div class="form-group">
            <label>Current Password:</label>
            <input type="password" name="current_password" required>
        </div>

        <div class="form-group">
            <label>New Password:</label>
            <input type="password" name="new_password" required minlength="10">
        </div>

        <div class="form-group">
            <label>Confirm New Password:</label>
            <input type="password" name="confirm_password" required>
        </div>

        <button type="submit" class="btn">Change Password</button>
    </form>
</div>

<?php include APP_PATH . '/Views/layout/footer.php'; ?>
