<?php
$pageTitle = 'Register';
include APP_PATH . '/Views/layout/header.php';
?>

<div class="card" style="max-width: 400px; margin: 3rem auto;">
    <h2>Register</h2>
    <form method="POST" action="/register">
        <!-- CSRF Protection -->
        <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">

        <div class="form-group">
            <label>Username:</label>
            <input type="text" name="username" required pattern="[a-zA-Z0-9_]{3,20}" title="3-20 alphanumeric characters">
        </div>

        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="email" required>
        </div>

        <div class="form-group">
            <label>Password:</label>
            <input type="password" name="password" required minlength="10" title="Minimum 10 characters, must include uppercase, lowercase, digit and symbol">
        </div>

        <div class="form-group">
            <label>Confirm Password:</label>
            <input type="password" name="confirm_password" required>
        </div>

        <button type="submit" class="btn">Register</button>
    </form>
    <p style="margin-top: 1rem;">Already have an account? <a href="/login">Login here</a></p>
</div>

<?php include APP_PATH . '/Views/layout/footer.php'; ?>
