<?php
$pageTitle = 'Login';
include APP_PATH . '/Views/layout/header.php';
?>

<div class="card" style="max-width: 400px; margin: 3rem auto;">
    <h2>Login</h2>
    <form method="POST" action="/login">
        <!-- CSRF Protection -->
        <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">

        <div class="form-group">
            <label>Username or Email:</label>
            <input type="text" name="username" required autocomplete="username">
        </div>

        <div class="form-group">
            <label>Password:</label>
            <input type="password" name="password" required autocomplete="current-password">
        </div>

        <button type="submit" class="btn">Login</button>
    </form>
    <p style="margin-top: 1rem;">Don't have an account? <a href="/register">Register here</a></p>
</div>

<?php include APP_PATH . '/Views/layout/footer.php'; ?>
