<?php
$pageTitle = '2FA Verification';
include APP_PATH . '/Views/layout/header.php';
?>

<div class="card" style="max-width: 400px; margin: 3rem auto;">
    <h2>🔐 Two-Factor Authentication</h2>
    <p>Enter the 6-digit code from your authenticator app:</p>

    <form method="POST" action="/verify-2fa">
        <!-- CSRF Protection -->
        <input type="hidden" name="csrf_token" value="<?= Security::generateCSRFToken() ?>">

        <div class="form-group">
            <label>Verification Code:</label>
            <input type="text" name="code" required pattern="[0-9]{6}|[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{4}" placeholder="000000 or backup code" maxlength="19" autocomplete="off">
        </div>

        <button type="submit" class="btn">Verify</button>
    </form>

    <p style="margin-top: 1rem; font-size: 0.9em;">Lost your device? Use a backup code instead.</p>
</div>

<?php include APP_PATH . '/Views/layout/footer.php'; ?>
