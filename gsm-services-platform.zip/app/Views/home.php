<?php
$pageTitle = 'Home';
include APP_PATH . '/Views/layout/header.php';
?>

<div style="text-align: center; padding: 3rem 0;">
    <h1>Welcome to <?= Security::escape(SITE_NAME) ?></h1>
    <p style="font-size: 1.2em; margin: 1rem 0;">Professional GSM Services Platform with Enterprise-Grade Security</p>

    <div style="margin: 2rem 0;">
        <a href="/services" class="btn">Browse Services</a>
        <?php if (!Session::isLoggedIn()): ?>
            <a href="/register" class="btn">Get Started</a>
        <?php endif; ?>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; margin: 2rem 0;">
    <div class="card" style="text-align: center;">
        <h3>🔒 Secure</h3>
        <p>2FA, encryption, CSRF protection, rate limiting, audit logs</p>
    </div>
    <div class="card" style="text-align: center;">
        <h3>⚡ Fast</h3>
        <p>Real-time order processing and instant notifications</p>
    </div>
    <div class="card" style="text-align: center;">
        <h3>📱 GSM Services</h3>
        <p>IMEI check, unlock, FRP removal, and more</p>
    </div>
    <div class="card" style="text-align: center;">
        <h3>💰 Wallet System</h3>
        <p>Prepaid balance, commission tracking, instant payments</p>
    </div>
</div>

<?php if (!empty($categories)): ?>
<h2 style="margin: 2rem 0;">Service Categories</h2>
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
    <?php foreach ($categories as $category): ?>
        <div class="card">
            <h3><?= Security::escape($category['name']) ?></h3>
            <p><?= Security::escape($category['description']) ?></p>
            <a href="/services?category=<?= Security::escape($category['slug']) ?>">View Services →</a>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include APP_PATH . '/Views/layout/footer.php'; ?>
