<?php
/**
 * Authentication Middleware
 * Ensures user is logged in and 2FA is verified
 */

class AuthMiddleware {
    public function handle() {
        Session::start();

        // Check if user is logged in
        if (!Session::isLoggedIn()) {
            Session::setFlash('error', 'Please login to continue', 'error');
            Router::redirect('/login');
            return false;
        }

        // Check if 2FA is required but not verified
        if (Session::requires2FA() && !Session::is2FAVerified()) {
            Router::redirect('/verify-2fa');
            return false;
        }

        // Check session timeout
        if (isset($_SESSION['last_activity']) &&
            time() - $_SESSION['last_activity'] > SESSION_LIFETIME) {
            Session::clearUser();
            Session::setFlash('error', 'Session expired. Please login again.', 'error');
            Router::redirect('/login');
            return false;
        }

        return true;
    }
}
