<?php
/**
 * Admin Access Middleware
 * Ensures user has admin privileges and passes IP whitelist
 */

class AdminMiddleware {
    private $allowedRoles = ['super_admin', 'admin', 'manager', 'staff'];

    public function handle() {
        Session::start();

        // Check authentication first
        $authMiddleware = new AuthMiddleware();
        if (!$authMiddleware->handle()) {
            return false;
        }

        // Check role
        $userRole = Session::getUserRole();
        if (!in_array($userRole, $this->allowedRoles)) {
            http_response_code(403);
            die('Access denied. Admin privileges required.');
        }

        // Check IP whitelist if configured
        if (!empty(ADMIN_IP_WHITELIST)) {
            $clientIP = Security::getClientIP();
            if (!Security::checkIPWhitelist($clientIP, ADMIN_IP_WHITELIST)) {
                Logger::warning('Admin access denied - IP not whitelisted', [
                    'ip' => $clientIP,
                    'user_id' => Session::getUserId()
                ]);
                http_response_code(403);
                die('Access denied. Your IP is not whitelisted.');
            }
        }

        // Force 2FA for super_admin
        if (FORCE_ADMIN_2FA && $userRole === 'super_admin') {
            $userModel = new User();
            $user = $userModel->findById(Session::getUserId());

            if (!$user['2fa_enabled']) {
                Session::setFlash('error', 'Two-factor authentication is required for admin access', 'error');
                Router::redirect('/profile/security');
                return false;
            }
        }

        return true;
    }
}
