<?php
/**
 * Application Entry Point
 * GSM Services Platform - Secure PHP Application
 */

// Load configuration and initialize
require_once __DIR__ . '/../config/config.php';

// Start session
Session::start();

// Maintenance mode check
if (MAINTENANCE_MODE && !Session::isLoggedIn()) {
    http_response_code(503);
    die('<h1>Maintenance Mode</h1><p>' . MAINTENANCE_MESSAGE . '</p>');
}

// Initialize router
$router = new Router();

// ============================================
// PUBLIC ROUTES
// ============================================

// Home
$router->get('/', function() {
    require APP_PATH . '/Controllers/HomeController.php';
    $controller = new HomeController();
    $controller->index();
});

// Authentication routes
$router->get('/login', function() {
    require APP_PATH . '/Controllers/AuthController.php';
    $controller = new AuthController();
    $controller->loginForm();
});

$router->post('/login', function() {
    require APP_PATH . '/Controllers/AuthController.php';
    $controller = new AuthController();
    $controller->login();
});

$router->get('/register', function() {
    require APP_PATH . '/Controllers/AuthController.php';
    $controller = new AuthController();
    $controller->registerForm();
});

$router->post('/register', function() {
    require APP_PATH . '/Controllers/AuthController.php';
    $controller = new AuthController();
    $controller->register();
});

$router->get('/logout', function() {
    require APP_PATH . '/Controllers/AuthController.php';
    $controller = new AuthController();
    $controller->logout();
});

$router->get('/verify-2fa', function() {
    require APP_PATH . '/Controllers/AuthController.php';
    $controller = new AuthController();
    $controller->verify2FAForm();
});

$router->post('/verify-2fa', function() {
    require APP_PATH . '/Controllers/AuthController.php';
    $controller = new AuthController();
    $controller->verify2FA();
});

// Services
$router->get('/services', function() {
    require APP_PATH . '/Controllers/ServiceController.php';
    $controller = new ServiceController();
    $controller->index();
});

$router->get('/service/{slug}', function($slug) {
    require APP_PATH . '/Controllers/ServiceController.php';
    $controller = new ServiceController();
    $controller->show($slug);
});

// ============================================
// AUTHENTICATED USER ROUTES
// ============================================

// Dashboard
$router->get('/dashboard', function() {
    require APP_PATH . '/Controllers/DashboardController.php';
    $controller = new DashboardController();
    $controller->index();
}, [AuthMiddleware::class]);

// Orders
$router->get('/orders', function() {
    require APP_PATH . '/Controllers/OrderController.php';
    $controller = new OrderController();
    $controller->index();
}, [AuthMiddleware::class]);

$router->post('/order/create', function() {
    require APP_PATH . '/Controllers/OrderController.php';
    $controller = new OrderController();
    $controller->create();
}, [AuthMiddleware::class]);

// Tickets
$router->get('/tickets', function() {
    require APP_PATH . '/Controllers/TicketController.php';
    $controller = new TicketController();
    $controller->index();
}, [AuthMiddleware::class]);

$router->get('/ticket/{id}', function($id) {
    require APP_PATH . '/Controllers/TicketController.php';
    $controller = new TicketController();
    $controller->show($id);
}, [AuthMiddleware::class]);

$router->post('/ticket/create', function() {
    require APP_PATH . '/Controllers/TicketController.php';
    $controller = new TicketController();
    $controller->create();
}, [AuthMiddleware::class]);

$router->post('/ticket/{id}/reply', function($id) {
    require APP_PATH . '/Controllers/TicketController.php';
    $controller = new TicketController();
    $controller->reply($id);
}, [AuthMiddleware::class]);

// Profile
$router->get('/profile', function() {
    require APP_PATH . '/Controllers/ProfileController.php';
    $controller = new ProfileController();
    $controller->index();
}, [AuthMiddleware::class]);

$router->post('/profile/update', function() {
    require APP_PATH . '/Controllers/ProfileController.php';
    $controller = new ProfileController();
    $controller->update();
}, [AuthMiddleware::class]);

$router->get('/profile/security', function() {
    require APP_PATH . '/Controllers/ProfileController.php';
    $controller = new ProfileController();
    $controller->security();
}, [AuthMiddleware::class]);

$router->post('/profile/enable-2fa', function() {
    require APP_PATH . '/Controllers/ProfileController.php';
    $controller = new ProfileController();
    $controller->enable2FA();
}, [AuthMiddleware::class]);

$router->post('/profile/disable-2fa', function() {
    require APP_PATH . '/Controllers/ProfileController.php';
    $controller = new ProfileController();
    $controller->disable2FA();
}, [AuthMiddleware::class]);

// ============================================
// ADMIN ROUTES
// ============================================

$router->get('/' . ADMIN_PATH, function() {
    require APP_PATH . '/Controllers/Admin/AdminDashboardController.php';
    $controller = new AdminDashboardController();
    $controller->index();
}, [AdminMiddleware::class]);

$router->get('/' . ADMIN_PATH . '/users', function() {
    require APP_PATH . '/Controllers/Admin/AdminUserController.php';
    $controller = new AdminUserController();
    $controller->index();
}, [AdminMiddleware::class]);

$router->get('/' . ADMIN_PATH . '/services', function() {
    require APP_PATH . '/Controllers/Admin/AdminServiceController.php';
    $controller = new AdminServiceController();
    $controller->index();
}, [AdminMiddleware::class]);

$router->get('/' . ADMIN_PATH . '/orders', function() {
    require APP_PATH . '/Controllers/Admin/AdminOrderController.php';
    $controller = new AdminOrderController();
    $controller->index();
}, [AdminMiddleware::class]);

$router->get('/' . ADMIN_PATH . '/tickets', function() {
    require APP_PATH . '/Controllers/Admin/AdminTicketController.php';
    $controller = new AdminTicketController();
    $controller->index();
}, [AdminMiddleware::class]);

$router->get('/' . ADMIN_PATH . '/settings', function() {
    require APP_PATH . '/Controllers/Admin/AdminSettingsController.php';
    $controller = new AdminSettingsController();
    $controller->index();
}, [AdminMiddleware::class]);

$router->post('/' . ADMIN_PATH . '/settings/update', function() {
    require APP_PATH . '/Controllers/Admin/AdminSettingsController.php';
    $controller = new AdminSettingsController();
    $controller->update();
}, [AdminMiddleware::class]);

$router->get('/' . ADMIN_PATH . '/logs', function() {
    require APP_PATH . '/Controllers/Admin/AdminLogsController.php';
    $controller = new AdminLogsController();
    $controller->index();
}, [AdminMiddleware::class]);

// ============================================
// API ROUTES (for AJAX calls)
// ============================================

$router->post('/api/check-imei', function() {
    require APP_PATH . '/Controllers/ApiController.php';
    $controller = new ApiController();
    $controller->checkIMEI();
}, [AuthMiddleware::class]);

// Dispatch router
$router->dispatch();
