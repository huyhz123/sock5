<?php
/**
 * Logger Class - Application logging with rotation
 */

class Logger {
    private static $logFile;
    private static $maxFileSize = 10485760; // 10MB

    private static function init() {
        if (!is_dir(LOG_PATH)) {
            mkdir(LOG_PATH, 0755, true);
        }
        self::$logFile = LOG_PATH . '/app.log';
    }

    private static function write($level, $message, $context = []) {
        self::init();

        // Log rotation
        if (file_exists(self::$logFile) && filesize(self::$logFile) > self::$maxFileSize) {
            rename(self::$logFile, self::$logFile . '.' . date('YmdHis'));
        }

        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'CLI';
        $user = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'guest';

        $contextStr = !empty($context) ? json_encode($context) : '';
        $logLine = "[{$timestamp}] [{$level}] [IP:{$ip}] [User:{$user}] {$message} {$contextStr}" . PHP_EOL;

        file_put_contents(self::$logFile, $logLine, FILE_APPEND | LOCK_EX);
    }

    public static function info($message, $context = []) {
        self::write('INFO', $message, $context);
    }

    public static function warning($message, $context = []) {
        self::write('WARNING', $message, $context);
    }

    public static function error($message, $context = []) {
        self::write('ERROR', $message, $context);

        // Log errors to database for admin dashboard
        try {
            $db = Database::getInstance();
            $db->insert('error_logs', [
                'level' => 'ERROR',
                'message' => $message,
                'context' => json_encode($context),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'CLI',
                'user_id' => $_SESSION['user_id'] ?? null,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        } catch (Exception $e) {
            // Fail silently if DB not available
        }
    }

    public static function critical($message, $context = []) {
        self::write('CRITICAL', $message, $context);

        // Send critical errors to admin via Telegram
        if (TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID) {
            $notification = "🚨 CRITICAL ERROR\n\n";
            $notification .= "Message: {$message}\n";
            $notification .= "Time: " . date('Y-m-d H:i:s') . "\n";
            $notification .= "IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'CLI');

            NotificationQueue::add('telegram', [
                'chat_id' => TELEGRAM_CHAT_ID,
                'message' => $notification
            ]);
        }
    }

    public static function debug($message, $context = []) {
        if (LOG_LEVEL === 'DEBUG' || DISPLAY_ERRORS) {
            self::write('DEBUG', $message, $context);
        }
    }

    public static function audit($action, $details = []) {
        // Audit logging for security events
        $db = Database::getInstance();

        try {
            $db->insert('audit_logs', [
                'user_id' => $_SESSION['user_id'] ?? null,
                'action' => $action,
                'details' => json_encode($details),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'CLI',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'created_at' => date('Y-m-d H:i:s')
            ]);
        } catch (Exception $e) {
            self::error('Failed to write audit log: ' . $e->getMessage());
        }

        self::info("AUDIT: {$action}", $details);
    }
}
