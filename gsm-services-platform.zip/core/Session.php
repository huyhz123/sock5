<?php
/**
 * Session Management Class
 * Handles secure session operations
 */

class Session {
    private static $started = false;

    /**
     * Start session with security measures
     */
    public static function start() {
        if (self::$started) {
            return;
        }

        // Session configuration already set in config.php
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        self::$started = true;

        // Validate session
        if (!self::validate()) {
            self::destroy();
            session_start();
        }

        // Update last activity
        $_SESSION['last_activity'] = time();

        // Set user agent if not set
        if (!isset($_SESSION['user_agent'])) {
            $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
        }

        // Set IP address if not set
        if (!isset($_SESSION['ip_address'])) {
            $_SESSION['ip_address'] = Security::getClientIP();
        }
    }

    /**
     * Validate session
     * @return bool
     */
    private static function validate() {
        // Check if session is expired
        if (isset($_SESSION['last_activity']) &&
            time() - $_SESSION['last_activity'] > SESSION_LIFETIME) {
            Logger::info('Session expired due to inactivity');
            return false;
        }

        // Check user agent (prevent session hijacking)
        if (isset($_SESSION['user_agent']) &&
            $_SESSION['user_agent'] !== ($_SERVER['HTTP_USER_AGENT'] ?? '')) {
            Logger::warning('Session hijack attempt detected - user agent mismatch');
            return false;
        }

        // Check IP address (strict mode - can be relaxed if users change IPs frequently)
        // Uncomment to enable strict IP checking:
        // if (isset($_SESSION['ip_address']) &&
        //     $_SESSION['ip_address'] !== Security::getClientIP()) {
        //     Logger::warning('Session hijack attempt detected - IP mismatch');
        //     return false;
        // }

        return true;
    }

    /**
     * Set session variable
     * @param string $key
     * @param mixed $value
     */
    public static function set($key, $value) {
        $_SESSION[$key] = $value;
    }

    /**
     * Get session variable
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function get($key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }

    /**
     * Check if session variable exists
     * @param string $key
     * @return bool
     */
    public static function has($key) {
        return isset($_SESSION[$key]);
    }

    /**
     * Delete session variable
     * @param string $key
     */
    public static function delete($key) {
        if (isset($_SESSION[$key])) {
            unset($_SESSION[$key]);
        }
    }

    /**
     * Destroy session
     */
    public static function destroy() {
        if (self::$started) {
            session_unset();
            session_destroy();
            self::$started = false;
        }
    }

    /**
     * Regenerate session ID (call on login, privilege change)
     */
    public static function regenerate() {
        if (self::$started) {
            session_regenerate_id(true);
            Logger::info('Session ID regenerated');
        }
    }

    /**
     * Set flash message
     * @param string $key
     * @param string $message
     * @param string $type (success, error, warning, info)
     */
    public static function setFlash($key, $message, $type = 'info') {
        $_SESSION['flash'][$key] = [
            'message' => $message,
            'type' => $type
        ];
    }

    /**
     * Get flash message and remove it
     * @param string $key
     * @return array|null
     */
    public static function getFlash($key) {
        if (isset($_SESSION['flash'][$key])) {
            $flash = $_SESSION['flash'][$key];
            unset($_SESSION['flash'][$key]);
            return $flash;
        }
        return null;
    }

    /**
     * Check if user is logged in
     * @return bool
     */
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    }

    /**
     * Get current user ID
     * @return int|null
     */
    public static function getUserId() {
        return $_SESSION['user_id'] ?? null;
    }

    /**
     * Get current user role
     * @return string|null
     */
    public static function getUserRole() {
        return $_SESSION['user_role'] ?? null;
    }

    /**
     * Set user session on login
     * @param array $user
     */
    public static function setUser($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();

        // Regenerate session ID on login
        self::regenerate();

        Logger::audit('User logged in', [
            'user_id' => $user['id'],
            'username' => $user['username']
        ]);
    }

    /**
     * Clear user session on logout
     */
    public static function clearUser() {
        $userId = $_SESSION['user_id'] ?? null;
        $username = $_SESSION['username'] ?? null;

        self::destroy();

        if ($userId) {
            Logger::audit('User logged out', [
                'user_id' => $userId,
                'username' => $username
            ]);
        }
    }

    /**
     * Check if user has 2FA enabled
     * @return bool
     */
    public static function requires2FA() {
        return isset($_SESSION['requires_2fa']) && $_SESSION['requires_2fa'] === true;
    }

    /**
     * Mark 2FA as verified
     */
    public static function mark2FAVerified() {
        $_SESSION['2fa_verified'] = true;
        $_SESSION['requires_2fa'] = false;
    }

    /**
     * Check if 2FA is verified
     * @return bool
     */
    public static function is2FAVerified() {
        return isset($_SESSION['2fa_verified']) && $_SESSION['2fa_verified'] === true;
    }
}
