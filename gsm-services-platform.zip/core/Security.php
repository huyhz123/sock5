<?php
/**
 * Security Class - Comprehensive security utilities
 * Handles: passwords, CSRF, XSS, input validation, encryption
 */

class Security {
    // Password complexity requirements
    const PASSWORD_MIN_LENGTH = 10;
    const PASSWORD_REQUIRE_UPPER = true;
    const PASSWORD_REQUIRE_LOWER = true;
    const PASSWORD_REQUIRE_DIGIT = true;
    const PASSWORD_REQUIRE_SYMBOL = true;

    // Common passwords to block (truncated list - add more in production)
    private static $commonPasswords = [
        'password123', 'admin123', 'qwerty123', '12345678', 'password',
        'letmein', 'welcome', 'monkey', '1234567890', 'abc123'
    ];

    /**
     * Hash password using bcrypt/argon2
     * @param string $password
     * @return string|false
     */
    public static function hashPassword($password) {
        // Use argon2id if available, otherwise bcrypt
        if (defined('PASSWORD_ARGON2ID')) {
            return password_hash($password, PASSWORD_ARGON2ID, [
                'memory_cost' => 65536,
                'time_cost' => 4,
                'threads' => 3
            ]);
        }
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    /**
     * Verify password
     * @param string $password
     * @param string $hash
     * @return bool
     */
    public static function verifyPassword($password, $hash) {
        return password_verify($password, $hash);
    }

    /**
     * Validate password complexity
     * @param string $password
     * @return array ['valid' => bool, 'errors' => array]
     */
    public static function validatePassword($password) {
        $errors = [];

        if (strlen($password) < self::PASSWORD_MIN_LENGTH) {
            $errors[] = "Password must be at least " . self::PASSWORD_MIN_LENGTH . " characters";
        }

        if (self::PASSWORD_REQUIRE_UPPER && !preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter";
        }

        if (self::PASSWORD_REQUIRE_LOWER && !preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter";
        }

        if (self::PASSWORD_REQUIRE_DIGIT && !preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one digit";
        }

        if (self::PASSWORD_REQUIRE_SYMBOL && !preg_match('/[^A-Za-z0-9]/', $password)) {
            $errors[] = "Password must contain at least one special character";
        }

        if (in_array(strtolower($password), self::$commonPasswords)) {
            $errors[] = "Password is too common, please choose a stronger password";
        }

        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }

    /**
     * Generate CSRF token
     * @return string
     */
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token']) ||
            !isset($_SESSION['csrf_token_time']) ||
            time() - $_SESSION['csrf_token_time'] > CSRF_TOKEN_LIFETIME) {

            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['csrf_token_time'] = time();
        }

        return $_SESSION['csrf_token'];
    }

    /**
     * Validate CSRF token
     * @param string $token
     * @return bool
     */
    public static function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
            return false;
        }

        // Check token expiration
        if (time() - $_SESSION['csrf_token_time'] > CSRF_TOKEN_LIFETIME) {
            return false;
        }

        // Use hash_equals to prevent timing attacks
        return hash_equals($_SESSION['csrf_token'], $token);
    }

    /**
     * Sanitize output to prevent XSS
     * @param string $data
     * @return string
     */
    public static function escape($data) {
        if (is_array($data)) {
            return array_map([self::class, 'escape'], $data);
        }
        return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    }

    /**
     * Validate email
     * @param string $email
     * @return bool
     */
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Validate username (alphanumeric + underscore, 3-20 chars)
     * @param string $username
     * @return bool
     */
    public static function validateUsername($username) {
        return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
    }

    /**
     * Validate phone number (international format)
     * @param string $phone
     * @return bool
     */
    public static function validatePhone($phone) {
        return preg_match('/^\+?[1-9]\d{1,14}$/', $phone);
    }

    /**
     * Validate integer in range
     * @param mixed $value
     * @param int $min
     * @param int $max
     * @return bool
     */
    public static function validateInt($value, $min = null, $max = null) {
        if (!is_numeric($value)) return false;
        $value = (int)$value;
        if ($min !== null && $value < $min) return false;
        if ($max !== null && $value > $max) return false;
        return true;
    }

    /**
     * Sanitize filename
     * @param string $filename
     * @return string
     */
    public static function sanitizeFilename($filename) {
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $filename);
        return substr($filename, 0, 255);
    }

    /**
     * Generate random token
     * @param int $length
     * @return string
     */
    public static function generateToken($length = 32) {
        return bin2hex(random_bytes($length));
    }

    /**
     * Encrypt data
     * @param string $data
     * @return string
     */
    public static function encrypt($data) {
        if (strlen(ENCRYPTION_KEY) < 32) {
            throw new Exception("Encryption key must be at least 32 characters");
        }

        $key = substr(hash('sha256', ENCRYPTION_KEY), 0, 32);
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);

        return base64_encode($encrypted . '::' . $iv);
    }

    /**
     * Decrypt data
     * @param string $data
     * @return string|false
     */
    public static function decrypt($data) {
        if (strlen(ENCRYPTION_KEY) < 32) {
            throw new Exception("Encryption key must be at least 32 characters");
        }

        $key = substr(hash('sha256', ENCRYPTION_KEY), 0, 32);
        $parts = explode('::', base64_decode($data), 2);

        if (count($parts) !== 2) {
            return false;
        }

        list($encrypted, $iv) = $parts;
        return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
    }

    /**
     * Get client IP address
     * @return string
     */
    public static function getClientIP() {
        $keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = trim(explode(',', $_SERVER[$key])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    /**
     * Check if IP is in whitelist
     * @param string $ip
     * @param string $whitelist
     * @return bool
     */
    public static function checkIPWhitelist($ip, $whitelist) {
        if (empty($whitelist)) return true;

        $allowedIPs = array_map('trim', explode(',', $whitelist));
        return in_array($ip, $allowedIPs);
    }

    /**
     * Rate limiting check
     * @param string $key
     * @param int $maxAttempts
     * @param int $window (seconds)
     * @return bool (true = allowed, false = rate limited)
     */
    public static function checkRateLimit($key, $maxAttempts, $window) {
        $db = Database::getInstance();

        // Clean old entries
        $db->query("DELETE FROM rate_limits WHERE expires_at < NOW()")
           ->execute();

        // Get current count
        $result = $db->query("SELECT attempts FROM rate_limits WHERE rate_key = :key AND expires_at > NOW()")
                     ->bind(':key', $key)
                     ->fetch();

        if ($result) {
            if ($result['attempts'] >= $maxAttempts) {
                return false; // Rate limited
            }

            // Increment counter
            $db->query("UPDATE rate_limits SET attempts = attempts + 1 WHERE rate_key = :key")
               ->bind(':key', $key)
               ->execute();
        } else {
            // Create new entry
            $expiresAt = date('Y-m-d H:i:s', time() + $window);
            $db->insert('rate_limits', [
                'rate_key' => $key,
                'attempts' => 1,
                'expires_at' => $expiresAt
            ]);
        }

        return true; // Allowed
    }

    /**
     * Record failed login attempt
     * @param string $identifier (username or email)
     * @param string $ip
     */
    public static function recordFailedLogin($identifier, $ip) {
        $db = Database::getInstance();
        $db->insert('failed_logins', [
            'identifier' => $identifier,
            'ip_address' => $ip,
            'attempted_at' => date('Y-m-d H:i:s')
        ]);

        Logger::warning("Failed login attempt", [
            'identifier' => $identifier,
            'ip' => $ip
        ]);
    }

    /**
     * Check account lockout
     * @param string $identifier
     * @return bool (true = locked)
     */
    public static function isAccountLocked($identifier) {
        $db = Database::getInstance();

        // Count failed attempts in the last 15 minutes
        $result = $db->query("
            SELECT COUNT(*) as count
            FROM failed_logins
            WHERE identifier = :identifier
            AND attempted_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
        ")
        ->bind(':identifier', $identifier)
        ->fetch();

        return ($result['count'] >= RATE_LIMIT_LOGIN_ATTEMPTS);
    }

    /**
     * Clear failed login attempts
     * @param string $identifier
     */
    public static function clearFailedLogins($identifier) {
        $db = Database::getInstance();
        $db->delete('failed_logins', 'identifier = :identifier', [
            ':identifier' => $identifier
        ]);
    }
}
