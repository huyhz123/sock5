<?php
/**
 * QR Code Generator (Simplified)
 * Generates QR code as PNG data URI for 2FA setup
 * This is a basic implementation - for production, consider using a full library
 */

class QRCode {
    /**
     * Generate QR code as data URI
     * @param string $data
     * @param int $size
     * @return string
     */
    public static function generate($data, $size = 200) {
        // Use Google Charts API as fallback (simple solution)
        // For production without external dependencies, implement full QR encoder
        // or use a single-file PHP QR library

        $url = 'https://chart.googleapis.com/chart?chs=' . $size . 'x' . $size . '&cht=qr&chl=' . urlencode($data);

        // Fetch QR code image
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $imageData = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200 && $imageData) {
            return 'data:image/png;base64,' . base64_encode($imageData);
        }

        // Fallback: generate simple text-based representation
        return self::generateFallback($data);
    }

    /**
     * Generate fallback text-based QR representation
     * @param string $data
     * @return string
     */
    private static function generateFallback($data) {
        // Create a simple placeholder image with text
        $width = 200;
        $height = 200;
        $image = imagecreate($width, $height);

        $bgColor = imagecolorallocate($image, 255, 255, 255);
        $textColor = imagecolorallocate($image, 0, 0, 0);

        $text = "QR Code\n(Manual Entry)";
        $x = 50;
        $y = 80;

        imagestring($image, 3, $x, $y, $text, $textColor);
        imagestring($image, 2, 10, 120, "Scan with", $textColor);
        imagestring($image, 2, 10, 140, "Authenticator App", $textColor);

        ob_start();
        imagepng($image);
        $imageData = ob_get_clean();
        imagedestroy($image);

        return 'data:image/png;base64,' . base64_encode($imageData);
    }

    /**
     * Alternative: Generate QR code using pure PHP (basic matrix)
     * This is a simplified version - not full QR spec implementation
     * For production, use a complete QR library or external service
     */
    public static function generateMatrix($data, $size = 200) {
        // Placeholder for pure PHP QR generation
        // In production, implement full QR code encoding or include library

        $matrixSize = 25; // 25x25 modules
        $moduleSize = (int)($size / $matrixSize);

        $image = imagecreate($size, $size);
        $white = imagecolorallocate($image, 255, 255, 255);
        $black = imagecolorallocate($image, 0, 0, 0);

        imagefill($image, 0, 0, $white);

        // Generate pseudo-random pattern based on data hash
        $hash = md5($data);
        for ($y = 0; $y < $matrixSize; $y++) {
            for ($x = 0; $x < $matrixSize; $x++) {
                $index = ($y * $matrixSize + $x) % strlen($hash);
                $value = hexdec($hash[$index]);

                if ($value > 7) { // Threshold
                    imagefilledrectangle(
                        $image,
                        $x * $moduleSize,
                        $y * $moduleSize,
                        ($x + 1) * $moduleSize - 1,
                        ($y + 1) * $moduleSize - 1,
                        $black
                    );
                }
            }
        }

        ob_start();
        imagepng($image);
        $imageData = ob_get_clean();
        imagedestroy($image);

        return 'data:image/png;base64,' . base64_encode($imageData);
    }
}
