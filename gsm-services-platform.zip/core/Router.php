<?php
/**
 * Router Class - Simple MVC router with middleware support
 */

class Router {
    private $routes = [];
    private $middlewares = [];

    /**
     * Add GET route
     * @param string $path
     * @param callable $callback
     * @param array $middlewares
     */
    public function get($path, $callback, $middlewares = []) {
        $this->addRoute('GET', $path, $callback, $middlewares);
    }

    /**
     * Add POST route
     * @param string $path
     * @param callable $callback
     * @param array $middlewares
     */
    public function post($path, $callback, $middlewares = []) {
        $this->addRoute('POST', $path, $callback, $middlewares);
    }

    /**
     * Add route
     * @param string $method
     * @param string $path
     * @param callable $callback
     * @param array $middlewares
     */
    private function addRoute($method, $path, $callback, $middlewares = []) {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'callback' => $callback,
            'middlewares' => $middlewares
        ];
    }

    /**
     * Register global middleware
     * @param callable $middleware
     */
    public function middleware($middleware) {
        $this->middlewares[] = $middleware;
    }

    /**
     * Dispatch request
     */
    public function dispatch() {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        // Remove trailing slash
        $uri = rtrim($uri, '/');
        if (empty($uri)) $uri = '/';

        foreach ($this->routes as $route) {
            if ($route['method'] === $method && $this->matchPath($route['path'], $uri, $params)) {
                // Run global middlewares
                foreach ($this->middlewares as $middleware) {
                    $result = call_user_func($middleware);
                    if ($result === false) {
                        return;
                    }
                }

                // Run route-specific middlewares
                foreach ($route['middlewares'] as $middleware) {
                    $middlewareClass = $middleware;
                    if (class_exists($middlewareClass)) {
                        $middlewareInstance = new $middlewareClass();
                        $result = $middlewareInstance->handle();
                        if ($result === false) {
                            return;
                        }
                    }
                }

                // Execute callback
                call_user_func_array($route['callback'], $params);
                return;
            }
        }

        // No route found - 404
        http_response_code(404);
        include APP_PATH . '/Views/errors/404.php';
    }

    /**
     * Match path with route pattern
     * @param string $pattern
     * @param string $uri
     * @param array &$params
     * @return bool
     */
    private function matchPath($pattern, $uri, &$params) {
        $params = [];

        // Convert pattern to regex
        $pattern = preg_replace('/\{([a-zA-Z0-9_]+)\}/', '([^/]+)', $pattern);
        $pattern = '#^' . $pattern . '$#';

        if (preg_match($pattern, $uri, $matches)) {
            array_shift($matches); // Remove full match
            $params = $matches;
            return true;
        }

        return false;
    }

    /**
     * Redirect to URL
     * @param string $url
     * @param int $code
     */
    public static function redirect($url, $code = 302) {
        header('Location: ' . $url, true, $code);
        exit();
    }

    /**
     * Return JSON response
     * @param mixed $data
     * @param int $code
     */
    public static function json($data, $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit();
    }
}
