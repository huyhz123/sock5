<?php
/**
 * TOTP (Time-based One-Time Password) Class
 * RFC 6238 implementation for 2FA
 * Compatible with Google Authenticator, Authy, etc.
 */

class TOTP {
    private $secret;
    private $period = 30; // Time step in seconds
    private $digits = 6; // Length of the OTP
    private $algorithm = 'sha1';

    /**
     * Constructor
     * @param string $secret Base32 encoded secret
     */
    public function __construct($secret = null) {
        if ($secret === null) {
            $this->secret = $this->generateSecret();
        } else {
            $this->secret = $secret;
        }
    }

    /**
     * Generate random secret (Base32 encoded)
     * @param int $length
     * @return string
     */
    public function generateSecret($length = 16) {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = '';
        for ($i = 0; $i < $length; $i++) {
            $secret .= $chars[random_int(0, 31)];
        }
        return $secret;
    }

    /**
     * Get secret
     * @return string
     */
    public function getSecret() {
        return $this->secret;
    }

    /**
     * Generate current TOTP code
     * @param int $timestamp
     * @return string
     */
    public function getCode($timestamp = null) {
        if ($timestamp === null) {
            $timestamp = time();
        }

        $time = floor($timestamp / $this->period);
        $time = pack('N*', 0) . pack('N*', $time);

        $secretKey = $this->base32Decode($this->secret);
        $hash = hash_hmac($this->algorithm, $time, $secretKey, true);

        $offset = ord($hash[strlen($hash) - 1]) & 0x0F;
        $code = (
            ((ord($hash[$offset]) & 0x7F) << 24) |
            ((ord($hash[$offset + 1]) & 0xFF) << 16) |
            ((ord($hash[$offset + 2]) & 0xFF) << 8) |
            (ord($hash[$offset + 3]) & 0xFF)
        ) % pow(10, $this->digits);

        return str_pad($code, $this->digits, '0', STR_PAD_LEFT);
    }

    /**
     * Verify TOTP code
     * @param string $code
     * @param int $discrepancy Number of periods to check (allows clock drift)
     * @param int $timestamp
     * @return bool
     */
    public function verifyCode($code, $discrepancy = 1, $timestamp = null) {
        if ($timestamp === null) {
            $timestamp = time();
        }

        // Check current and nearby time windows
        for ($i = -$discrepancy; $i <= $discrepancy; $i++) {
            $checkTime = $timestamp + ($i * $this->period);
            if ($this->getCode($checkTime) === $code) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get provisioning URI for QR code
     * @param string $issuer
     * @param string $accountName
     * @return string
     */
    public function getProvisioningUri($issuer, $accountName) {
        $params = [
            'secret' => $this->secret,
            'issuer' => $issuer,
            'algorithm' => strtoupper($this->algorithm),
            'digits' => $this->digits,
            'period' => $this->period
        ];

        $label = $issuer . ':' . $accountName;
        $query = http_build_query($params);

        return 'otpauth://totp/' . rawurlencode($label) . '?' . $query;
    }

    /**
     * Base32 decode
     * @param string $data
     * @return string
     */
    private function base32Decode($data) {
        $data = strtoupper($data);
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $binary = '';

        for ($i = 0; $i < strlen($data); $i++) {
            $char = $data[$i];
            if ($char === '=') continue;

            $pos = strpos($chars, $char);
            if ($pos === false) {
                throw new Exception('Invalid base32 character: ' . $char);
            }

            $binary .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
        }

        $result = '';
        for ($i = 0; $i < strlen($binary); $i += 8) {
            $chunk = substr($binary, $i, 8);
            if (strlen($chunk) === 8) {
                $result .= chr(bindec($chunk));
            }
        }

        return $result;
    }

    /**
     * Generate backup codes
     * @param int $count
     * @return array
     */
    public static function generateBackupCodes($count = 10) {
        $codes = [];
        for ($i = 0; $i < $count; $i++) {
            $code = '';
            for ($j = 0; $j < 4; $j++) {
                $code .= str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT);
                if ($j < 3) $code .= '-';
            }
            $codes[] = $code;
        }
        return $codes;
    }

    /**
     * Hash backup code for storage
     * @param string $code
     * @return string
     */
    public static function hashBackupCode($code) {
        return hash('sha256', $code);
    }
}
