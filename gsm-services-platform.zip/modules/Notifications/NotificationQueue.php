<?php
/**
 * Notification Queue System
 * Handles Telegram, WhatsApp, and Email notifications with retry logic
 */

class NotificationQueue {
    private static $db;

    private static function init() {
        if (!self::$db) {
            self::$db = Database::getInstance();
        }
    }

    /**
     * Add notification to queue
     * @param string $type (telegram, whatsapp, email)
     * @param array $data
     */
    public static function add($type, $data) {
        self::init();

        $recipient = $data['recipient'] ?? $data['chat_id'] ?? $data['to'] ?? '';
        $message = $data['message'] ?? '';

        try {
            self::$db->insert('notifications_queue', [
                'type' => $type,
                'recipient' => $recipient,
                'message' => $message,
                'metadata' => json_encode($data),
                'status' => 'pending'
            ]);

            Logger::info("Notification queued: {$type} to {$recipient}");
            return true;
        } catch (Exception $e) {
            Logger::error("Failed to queue notification: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send Telegram message
     */
    private static function sendTelegram($data) {
        if (empty(TELEGRAM_BOT_TOKEN)) {
            throw new Exception("Telegram bot token not configured");
        }

        $chatId = $data['chat_id'] ?? TELEGRAM_CHAT_ID;
        $message = $data['message'];

        $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
        $postData = [
            'chat_id' => $chatId,
            'text' => $message,
            'parse_mode' => 'HTML'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            throw new Exception("Telegram API error: HTTP {$httpCode} - {$response}");
        }

        $result = json_decode($response, true);
        if (!$result['ok']) {
            throw new Exception("Telegram API error: " . ($result['description'] ?? 'Unknown error'));
        }

        return true;
    }

    /**
     * Send WhatsApp message
     */
    private static function sendWhatsApp($data) {
        if (empty(WHATSAPP_TOKEN) || empty(WHATSAPP_PHONE_ID)) {
            throw new Exception("WhatsApp credentials not configured");
        }

        $to = $data['to'] ?? $data['recipient'];
        $message = $data['message'];

        $url = WHATSAPP_API_URL . "/" . WHATSAPP_PHONE_ID . "/messages";
        $postData = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'text',
            'text' => ['body' => $message]
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . WHATSAPP_TOKEN,
            'Content-Type: application/json'
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            throw new Exception("WhatsApp API error: HTTP {$httpCode} - {$response}");
        }

        return true;
    }

    /**
     * Process pending notifications
     */
    public static function processPending($limit = 10) {
        self::init();

        $notifications = self::$db->query("
            SELECT * FROM notifications_queue
            WHERE status = 'pending' AND retry_count < max_retries
            ORDER BY created_at ASC
            LIMIT :limit
        ")->bind(':limit', $limit, PDO::PARAM_INT)->fetchAll();

        $processed = 0;
        $sent = 0;
        $failed = 0;

        foreach ($notifications as $notification) {
            $processed++;

            try {
                $data = json_decode($notification['metadata'], true);

                // Send based on type
                switch ($notification['type']) {
                    case 'telegram':
                        self::sendTelegram($data);
                        break;
                    case 'whatsapp':
                        self::sendWhatsApp($data);
                        break;
                    default:
                        throw new Exception("Unknown notification type: {$notification['type']}");
                }

                // Mark as sent
                self::$db->update('notifications_queue', [
                    'status' => 'sent',
                    'sent_at' => date('Y-m-d H:i:s')
                ], 'id = :id', [':id' => $notification['id']]);

                $sent++;
                Logger::info("Notification sent: {$notification['type']} #{$notification['id']}");

            } catch (Exception $e) {
                $failed++;
                $retryCount = $notification['retry_count'] + 1;
                $status = ($retryCount >= $notification['max_retries']) ? 'failed' : 'pending';

                self::$db->update('notifications_queue', [
                    'status' => $status,
                    'retry_count' => $retryCount,
                    'last_error' => $e->getMessage()
                ], 'id = :id', [':id' => $notification['id']]);

                Logger::error("Notification failed: {$notification['type']} #{$notification['id']} - " . $e->getMessage());
            }
        }

        return [
            'processed' => $processed,
            'sent' => $sent,
            'failed' => $failed
        ];
    }

    /**
     * Send order notification
     */
    public static function sendOrderNotification($order, $user) {
        $message = "🔔 <b>New Order</b>\n\n";
        $message .= "Order #: {$order['order_number']}\n";
        $message .= "User: {$user['username']}\n";
        $message .= "Service: {$order['service_name']}\n";
        $message .= "Price: $" . number_format($order['price'], 2) . "\n";
        $message .= "Status: {$order['status']}\n";
        $message .= "Time: " . date('Y-m-d H:i:s');

        self::add('telegram', [
            'chat_id' => TELEGRAM_CHAT_ID,
            'message' => $message
        ]);
    }

    /**
     * Send payment notification
     */
    public static function sendPaymentNotification($payment, $user) {
        $message = "💰 <b>Payment Received</b>\n\n";
        $message .= "Transaction #: {$payment['transaction_id']}\n";
        $message .= "User: {$user['username']}\n";
        $message .= "Amount: $" . number_format($payment['amount'], 2) . "\n";
        $message .= "Method: {$payment['payment_method']}\n";
        $message .= "Time: " . date('Y-m-d H:i:s');

        self::add('telegram', [
            'chat_id' => TELEGRAM_CHAT_ID,
            'message' => $message
        ]);
    }
}
