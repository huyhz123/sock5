<?php
/**
 * Notification Queue Processor Cron Job
 * Run every minute: * * * * * php /path/to/cron/send_notifications.php
 */

// Load configuration
require_once __DIR__ . '/../config/config.php';

echo "[" . date('Y-m-d H:i:s') . "] Starting notification processor...\n";

try {
    $result = NotificationQueue::processPending(50);

    echo "Processed: {$result['processed']}\n";
    echo "Sent: {$result['sent']}\n";
    echo "Failed: {$result['failed']}\n";

    Logger::info('Notification cron completed', $result);

} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    Logger::error('Notification cron failed: ' . $e->getMessage());
}

echo "[" . date('Y-m-d H:i:s') . "] Notification processor finished.\n";
