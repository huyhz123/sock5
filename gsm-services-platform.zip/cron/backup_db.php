<?php
/**
 * Database Backup Cron Job
 * Run daily: 0 2 * * * php /path/to/cron/backup_db.php
 */

// Load configuration
require_once __DIR__ . '/../config/config.php';

echo "[" . date('Y-m-d H:i:s') . "] Starting database backup...\n";

$backupDir = BACKUP_PATH;
if (!is_dir($backupDir)) {
    mkdir($backupDir, 0755, true);
}

$timestamp = date('Y-m-d_H-i-s');
$backupFile = $backupDir . '/backup_' . $timestamp . '.sql';
$compressedFile = $backupFile . '.gz';

try {
    // Dump database
    $command = sprintf(
        'mysqldump -h%s -u%s -p%s %s > %s 2>&1',
        escapeshellarg(DB_HOST),
        escapeshellarg(DB_USER),
        escapeshellarg(DB_PASS),
        escapeshellarg(DB_NAME),
        escapeshellarg($backupFile)
    );

    exec($command, $output, $returnCode);

    if ($returnCode !== 0) {
        throw new Exception("Backup failed with code {$returnCode}: " . implode("\n", $output));
    }

    // Compress backup
    exec("gzip " . escapeshellarg($backupFile));

    $fileSize = filesize($compressedFile);
    echo "Backup created: {$compressedFile} (" . round($fileSize / 1024 / 1024, 2) . " MB)\n";

    Logger::info('Database backup completed', [
        'file' => $compressedFile,
        'size' => $fileSize
    ]);

    // Clean old backups
    $files = glob($backupDir . '/backup_*.sql.gz');
    $retentionTime = time() - (BACKUP_RETENTION_DAYS * 24 * 60 * 60);

    foreach ($files as $file) {
        if (filemtime($file) < $retentionTime) {
            unlink($file);
            echo "Deleted old backup: " . basename($file) . "\n";
        }
    }

    // Optional: Upload to SFTP
    if (!empty(getenv('SFTP_HOST'))) {
        echo "Uploading to SFTP...\n";
        // Implement SFTP upload here
    }

} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    Logger::error('Database backup failed: ' . $e->getMessage());

    // Send critical alert
    if (TELEGRAM_BOT_TOKEN) {
        NotificationQueue::add('telegram', [
            'chat_id' => TELEGRAM_CHAT_ID,
            'message' => "🚨 Database backup failed: " . $e->getMessage()
        ]);
    }
}

echo "[" . date('Y-m-d H:i:s') . "] Database backup finished.\n";
