<?php
// Vietnamese Language File
return [
    'site_name' => 'Nền tảng dịch vụ GSM',
    'welcome' => 'Chào mừng',
    'login' => 'Đăng nhập',
    'register' => 'Đăng ký',
    'logout' => 'Đăng xuất',
    'dashboard' => 'Bảng điều khiển',
    'profile' => 'Hồ sơ',
    'services' => 'Dịch vụ',
    'orders' => 'Đơn hàng',
    'tickets' => 'Ticket hỗ trợ',
    'balance' => 'Số dư',
    'submit' => 'Gửi',
    'cancel' => 'Hủy',
    'save' => 'Lưu',
    'delete' => 'Xóa',
    'edit' => 'Sửa',
    'view' => 'Xem',
];
