<?php
// English Language File
return [
    'site_name' => 'GSM Services Platform',
    'welcome' => 'Welcome',
    'login' => 'Login',
    'register' => 'Register',
    'logout' => 'Logout',
    'dashboard' => 'Dashboard',
    'profile' => 'Profile',
    'services' => 'Services',
    'orders' => 'Orders',
    'tickets' => 'Tickets',
    'balance' => 'Balance',
    'submit' => 'Submit',
    'cancel' => 'Cancel',
    'save' => 'Save',
    'delete' => 'Delete',
    'edit' => 'Edit',
    'view' => 'View',
];
