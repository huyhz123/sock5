<?php
/**
 * Security Check Script
 * Validates security configuration and identifies potential vulnerabilities
 * Run: php scripts/security_check.php
 */

echo "========================================\n";
echo "GSM Services Platform - Security Check\n";
echo "========================================\n\n";

$issues = [];
$warnings = [];
$passed = [];

// Load configuration
if (!file_exists(__DIR__ . '/../.env')) {
    $issues[] = ".env file not found - copy .env.sample to .env";
} else {
    require_once __DIR__ . '/../config/config.php';
    $passed[] = ".env file exists";
}

// Check 1: Encryption key
if (ENCRYPTION_KEY === '__CHANGE_ME__' || strlen(ENCRYPTION_KEY) < 32) {
    $issues[] = "ENCRYPTION_KEY not set or too short (min 32 chars)";
} else {
    $passed[] = "Encryption key configured";
}

// Check 2: Database credentials
if (DB_PASS === '__CHANGE_DB_PASSWORD__' || empty(DB_PASS)) {
    $issues[] = "Database password not changed from default";
} else {
    $passed[] = "Database password set";
}

// Check 3: Session security
if (ini_get('session.cookie_httponly') != '1') {
    $warnings[] = "session.cookie_httponly should be 1";
} else {
    $passed[] = "Session cookies are HTTP-only";
}

// Check 4: File permissions
$criticalDirs = [
    __DIR__ . '/../uploads' => '0755',
    __DIR__ . '/../logs' => '0755',
    __DIR__ . '/../config' => '0755'
];

foreach ($criticalDirs as $dir => $expectedPerm) {
    if (is_dir($dir)) {
        $perms = substr(sprintf('%o', fileperms($dir)), -4);
        if ($perms > $expectedPerm) {
            $warnings[] = "Directory {$dir} has loose permissions: {$perms} (expected: {$expectedPerm})";
        } else {
            $passed[] = "Directory permissions OK: " . basename($dir);
        }
    }
}

// Check 5: Configuration files protected
$configFile = __DIR__ . '/../config/config.php';
if (is_readable($configFile)) {
    $perms = substr(sprintf('%o', fileperms($configFile)), -4);
    if ($perms > '0644') {
        $warnings[] = "config.php has overly permissive permissions: {$perms}";
    } else {
        $passed[] = "Config file permissions OK";
    }
}

// Check 6: .htaccess exists
$htaccess = __DIR__ . '/../public/.htaccess';
if (!file_exists($htaccess)) {
    $warnings[] = ".htaccess file missing in public/ directory";
} else {
    $passed[] = ".htaccess file exists";
}

// Check 7: Sensitive tokens
$sensitiveKeys = ['TELEGRAM_BOT_TOKEN', 'WHATSAPP_TOKEN', 'STRIPE_SECRET_KEY'];
$unconfigured = [];
foreach ($sensitiveKeys as $key) {
    $value = constant($key);
    if (empty($value) || strpos($value, '__') === 0) {
        $unconfigured[] = $key;
    }
}
if (!empty($unconfigured)) {
    $warnings[] = "API tokens not configured: " . implode(', ', $unconfigured);
} else {
    $passed[] = "API tokens configured";
}

// Check 8: Error display
if (DISPLAY_ERRORS) {
    $warnings[] = "DISPLAY_ERRORS is enabled - disable in production";
} else {
    $passed[] = "Error display disabled";
}

// Check 9: HTTPS enforcement
if (!FORCE_HTTPS) {
    $warnings[] = "FORCE_HTTPS is disabled - enable for production";
} else {
    $passed[] = "HTTPS enforcement enabled";
}

// Check 10: 2FA settings
if (!ENABLE_2FA) {
    $warnings[] = "2FA is disabled globally";
} else {
    $passed[] = "2FA enabled";
}

// Check 11: CSRF token in sample views (scan PHP files)
$viewsDir = __DIR__ . '/../app/Views';
if (is_dir($viewsDir)) {
    $formsWithoutCSRF = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($viewsDir));

    foreach ($iterator as $file) {
        if ($file->isFile() && $file->getExtension() === 'php') {
            $content = file_get_contents($file->getPathname());
            if (preg_match('/<form[^>]*method=["\']post["\']/i', $content)) {
                if (!preg_match('/csrf_token/', $content)) {
                    $formsWithoutCSRF[] = str_replace($viewsDir . '/', '', $file->getPathname());
                }
            }
        }
    }

    if (!empty($formsWithoutCSRF)) {
        $warnings[] = "Forms missing CSRF tokens in: " . implode(', ', $formsWithoutCSRF);
    } else {
        $passed[] = "All forms have CSRF protection";
    }
}

// Check 12: Default admin credentials
if (file_exists(__DIR__ . '/../database.sql')) {
    $sql = file_get_contents(__DIR__ . '/../database.sql');
    if (strpos($sql, '__CHANGE_ME__') !== false) {
        $issues[] = "Default admin password detected in database.sql - change immediately after installation";
    }
}

// Print results
echo "PASSED CHECKS (" . count($passed) . "):\n";
foreach ($passed as $item) {
    echo "  ✓ {$item}\n";
}

echo "\nWARNINGS (" . count($warnings) . "):\n";
if (empty($warnings)) {
    echo "  None\n";
} else {
    foreach ($warnings as $item) {
        echo "  ⚠ {$item}\n";
    }
}

echo "\nCRITICAL ISSUES (" . count($issues) . "):\n";
if (empty($issues)) {
    echo "  None\n";
} else {
    foreach ($issues as $item) {
        echo "  ✗ {$item}\n";
    }
}

echo "\n========================================\n";

if (empty($issues) && empty($warnings)) {
    echo "✓ All security checks passed!\n";
    exit(0);
} elseif (empty($issues)) {
    echo "⚠ Security check completed with warnings\n";
    exit(1);
} else {
    echo "✗ Security check failed - fix critical issues!\n";
    exit(2);
}
